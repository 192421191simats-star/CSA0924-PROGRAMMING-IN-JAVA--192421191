"""
Builds the graphs for the Assignment 3 report from QN/data/*.csv and QN/output/*.txt.
Usage: python3 tools/make_graphs.py   (from the repository root, after run_all.sh)
"""
import csv
import re
from collections import defaultdict
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent.parent
SLOTS = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
MARKERS = ["o", "s", "^", "D", "v", "P", "X", "*"]
INK, MUTED, GRID = "#2b2b29", "#6b6a64", "#e4e3de"


def setup(ax, title, xlabel, ylabel, logx=False, logy=False):
    ax.set_title(title, fontsize=11, color=INK, loc="left", fontweight="bold")
    ax.set_xlabel(xlabel, color=MUTED, fontsize=9)
    ax.set_ylabel(ylabel, color=MUTED, fontsize=9)
    if logx: ax.set_xscale("log", base=2)
    if logy: ax.set_yscale("log")
    ax.grid(True, color=GRID, linewidth=0.8)
    for s in ["top", "right"]: ax.spines[s].set_visible(False)
    for s in ["left", "bottom"]: ax.spines[s].set_color(GRID)
    ax.tick_params(colors=MUTED, labelsize=8)


def line(ax, x, y, i, label, **kw):
    ax.plot(x, y, color=SLOTS[i], marker=MARKERS[i], markersize=6, linewidth=2, label=label, **kw)


def save(fig, q, name):
    out = ROOT / q / "graphs"
    out.mkdir(exist_ok=True)
    fig.tight_layout()
    fig.savefig(out / name, dpi=140, facecolor="#fcfcfb")
    plt.close(fig)
    print("  ", f"{q}/graphs/{name}")


def rows(q, f):
    with open(ROOT / q / "data" / f) as fh:
        return list(csv.DictReader(fh))


def legend(ax, **kw):
    ax.legend(frameon=False, fontsize=8, labelcolor=INK, **kw)


def q1():
    r = rows("Q1", "q1_exception_cost.csv")
    agg = defaultdict(list)
    for x in r: agg[(x["mechanism"], int(x["depth"]))].append(float(x["ns_per_failure"]))
    mechs = list(dict.fromkeys(x["mechanism"] for x in r))
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    for i, m in enumerate(mechs):
        pts = sorted((d, max(sum(v) / len(v), 0.1)) for (mm, d), v in agg.items() if mm == m)
        line(ax, [p[0] for p in pts], [p[1] for p in pts], i, m)
    setup(ax, "Cost of reporting one failure", "call depth (frames between failure and handler)", "ns per failed call", False, True)
    ax.set_xscale("log")
    legend(ax)
    save(fig, "Q1", "q1_exception_cost.png")


def q2():
    r = rows("Q2", "q2_exception_memory.csv")
    fig, ax = plt.subplots(figsize=(8, 4.2))
    names = [x["exception"] for x in r]
    xs = range(len(names))
    ax.bar([i - 0.2 for i in xs], [int(x["retained_bytes_lazy"]) for x in r], 0.38, color=SLOTS[0], label="retained, trace not yet read")
    ax.bar([i + 0.2 for i in xs], [int(x["retained_bytes_materialised"]) for x in r], 0.38, color=SLOTS[1], label="retained after getStackTrace()")
    setup(ax, "Memory held by one exception object (30 frames deep)", "", "bytes")
    ax.set_xticks(list(xs)); ax.set_xticklabels([n.replace(", ", ",\n") for n in names], fontsize=7)
    ax.grid(axis="x", visible=False)
    legend(ax)
    save(fig, "Q2", "q2_exception_memory.png")


def q3():
    fig, ax = plt.subplots(figsize=(7.5, 4.2))
    for i, (f, label) in enumerate([("LeakStress_V1.txt", "V1 manual close (as found)"), ("LeakStress_V3.txt", "V3 try-with-resources")]):
        p = ROOT / "Q3" / "output" / f
        if not p.exists(): continue
        pts = [(0, 0)]
        for l in p.read_text().splitlines():
            m = re.match(r"run (\d+): OS fds (\d+)", l)
            if m: pts.append((int(m.group(1)), int(m.group(2))))
            m = re.match(r"open fds at failure: (\d+)", l)
            if m: pts.append((pts[-1][0] + 1, int(m.group(1))))
        pts[0] = (0, pts[1][1] if len(pts) > 1 else 0)
        line(ax, [p[0] for p in pts], [p[1] for p in pts], i, label)
    ax.axhline(256, color=SLOTS[7], linestyle="--", linewidth=1)
    ax.text(5, 262, "ulimit -n 256: 'Too many open files'", color=INK, fontsize=8)
    setup(ax, "Open file descriptors while the failing report is regenerated", "report runs", "open file descriptors")
    legend(ax, loc="center right")
    save(fig, "Q3", "q3_open_files.png")


def q4():
    r = rows("Q4", "q4_pool.csv")
    agg = defaultdict(lambda: [0, 0, 0])
    for x in r:
        a = agg[int(x["p"])]; a[0] += float(x["executor_ms"]); a[1] += float(x["manual_ms"]); a[2] += 1
    ps = sorted(agg)
    fig, ax = plt.subplots(figsize=(7, 4.2))
    base = agg[1][0] / agg[1][2]
    line(ax, ps, [base / p for p in ps], 2, "expected n/p x t", linestyle="--")
    line(ax, ps, [agg[p][0] / agg[p][2] for p in ps], 0, "ExecutorService fixed pool")
    line(ax, ps, [agg[p][1] / agg[p][2] for p in ps], 1, "manual Thread objects")
    setup(ax, "400 scripts: completion time vs threads", "threads p", "ms", True, True)
    legend(ax)
    save(fig, "Q4", "q4_pool.png")


def q5():
    r = rows("Q5", "q5_timing.csv")
    agg = defaultdict(list)
    for x in r: agg[x["version"]].append(float(x["ms"]))
    names = list(agg)
    fig, ax = plt.subplots(figsize=(8, 4.2))
    cols = [SLOTS[7] if n == "no synchronization" else SLOTS[0] for n in names]
    ax.bar(range(len(names)), [sum(agg[n]) / len(agg[n]) for n in names], 0.6, color=cols)
    for i, n in enumerate(names):
        ax.text(i, sum(agg[n]) / len(agg[n]) * 1.02, f"{sum(agg[n]) / len(agg[n]):.1f}", ha="center", fontsize=8, color=INK)
    setup(ax, "10,000 booking requests, 8 threads (red = incorrect: double bookings)", "", "ms (mean of 7 runs)")
    ax.set_xticks(range(len(names))); import textwrap
    ax.set_xticklabels([textwrap.fill(n.replace(".", ". "), 14) for n in names], fontsize=8)
    ax.grid(axis="x", visible=False)
    save(fig, "Q5", "q5_timing.png")


def q6():
    r = rows("Q6", "q6_counter_trace.csv")
    fig, ax = plt.subplots(figsize=(8, 3.8))
    ax.step(range(len(r)), [int(x["count_after"]) for x in r], where="post", color=SLOTS[0], linewidth=2, label="tokens on the counter")
    ax.axhline(5, color=SLOTS[7], linestyle="--", linewidth=1); ax.axhline(0, color=SLOTS[7], linestyle="--", linewidth=1)
    ax.text(0.5, 5.15, "capacity 5", fontsize=8, color=INK)
    setup(ax, "Counter size after every put/take (correct version)", "operation number", "tokens")
    ax.set_ylim(-0.5, 5.8)
    save(fig, "Q6", "q6_counter_size.png")


def q7():
    r = rows("Q7", "q7_pool.csv")
    agg = defaultdict(list)
    for x in r: agg[(x["mode"], int(x["pool"]))].append(float(x["ms"]))
    fig, ax = plt.subplots(figsize=(7, 4.2))
    for i, (mode, label) in enumerate([("local", "local disk"), ("latency1ms", "storage latency 1 ms / file")]):
        ps = sorted(p for (m, p) in agg if m == mode)
        base = sum(agg[(mode, 1)]) / len(agg[(mode, 1)])
        line(ax, ps, [base / (sum(agg[(mode, p)]) / len(agg[(mode, p)])) for p in ps], i, label)
    ps = sorted({p for (_, p) in agg})
    line(ax, ps, ps, 2, "ideal (speed-up = p)", linestyle="--")
    setup(ax, "Speed-up of 10,000 score files vs pool size (2 CPUs)", "threads in pool", "speed-up over 1 thread", True, True)
    legend(ax)
    save(fig, "Q7", "q7_speedup.png")


if __name__ == "__main__":
    for f in (q1, q2, q3, q4, q5, q6, q7):
        try:
            f()
        except FileNotFoundError as e:
            print("   skipped", f.__name__, e)
