# CSA09 – Assignment 3 (CO3): Exception Handling and Multithreading (Pair Work)

| | |
|---|---|
| **Name** | `Prabhenjan srikanth R` (Student A / B) |
| **Register Number** | `192421191` |
| **Partner** | `<PARTNER NAME, REGISTER NUMBER>` – repository: `<partner's GitHub link>` |
| **Java version** | OpenJDK 21 (compiles on JDK 17+) |
| **Report** | [`report/Assignment3_Report.pdf`](report/Assignment3_Report.pdf) (joint report, sections labelled Student A / Student B) |

> Pair-work rule: **both students execute every question in their own repository.**

## Repository layout

```
QN/
├── *.java or src/...      source code (Complete-the-Code programs + experiment programs)
├── input/                 input files (accounts, cards, test cases, scenarios, store files, jdb script, ...)
├── data/                  raw measurements (CSV) and logs used as evidence
├── output/*.txt           console output of every program (commands at the top, exit code at the end)
├── graphs/*.png           graphs drawn from data/
└── screenshots/*.png      output screenshots
report/                    joint report (pdf, docx, md) + diagrams/
run_all.sh                 compiles and runs everything (about 6-8 minutes, Linux/macOS/Git Bash)
tools/                     make_graphs.py, render_screenshots.py, build_report.py
```

Q7's 10,000 score files are **generated** (`work/` is not committed): `java -cp out ScoreFileGenerator work 10000 2026`.

## How to compile and run

```bash
bash run_all.sh                 # everything      (or: bash run_all.sh Q3 Q6)
python3 tools/make_graphs.py    # rebuild graphs (needs matplotlib)
```

| Q | Compile (inside the folder) | Run |
|---|---|---|
| Q1 | `javac -d out AtmSimulation.java AtmTestRunner.java UncaughtDemo.java ExceptionCostBenchmark.java` | `java -cp out AtmTestRunner input/test_cases.csv` · `java -cp out AtmSimulation input/card_valid.txt` (interactive) · `java -cp out UncaughtDemo < /dev/null` · `javac -d /tmp/x compile_error_demo/BadCatchOrder.java` (fails on purpose) · `java -cp out ExceptionCostBenchmark` |
| Q2 *(Complete the Code)* | `javac -d out StorageDemo.java` | `java -cp out StorageDemo` (no-cause variant: `javac -d out_nocause no_cause_variant/StorageDemo.java`) |
| Q2 | `javac -d out $(find src -name "*.java")` | `java -cp out portal.PortalDemo input` · `java -Xmx1g -cp out portal.CheckedVsUncheckedCost` |
| Q3 | `javac -g -d out $(find src -name "*.java")` | `java -cp out report.ReportDemo input` · `bash -c 'ulimit -n 256; java -cp out report.LeakStress input/stores_failing V1'` · jdb: see `run_all.sh` |
| Q4 | `javac -d out ThreadLab.java DaemonDemo.java OnceOrder.java PoolVsThreads.java` | `java -cp out ThreadLab input/stations.txt` · `java -cp out DaemonDemo` · `java -XX:NativeMemoryTracking=summary -cp out PoolVsThreads` |
| Q5 *(Complete the Code)* | `javac -d out_unsync before_todo/SeatBooking.java` / `javac -d out SeatBooking.java` | `java -cp out_unsync SeatBooking` (10×) / `java -cp out SeatBooking` |
| Q5 | `javac -d out BookingLab.java` | `java -cp out BookingLab` |
| Q6 *(Complete the Code)* | `javac -d out TokenCounter.java` (if-variant: `javac -d out_if if_variant/TokenCounter.java`) | `java -cp out TokenCounter` |
| Q6 | `javac -d out ProducerConsumerLab.java DeadlockLab.java` | `java -cp out ProducerConsumerLab` · `java -cp out DeadlockLab` |
| Q7 | `javac -d out *.java` | `java -cp out ScoreFileGenerator work 10000 2026` then `java -Xmx1g -cp out Q7Experiments input/handcheck work` |

## Result of each question

| Q | Result |
|---|---|
| Q1 | 10/10 designed inputs took the intended catch path, finally ran every time; uncaught `NoSuchElementException` stack trace captured; wrong catch order rejected by the compiler. Throwing an exception 100 frames deep: 7.5 µs and 2.8 KB vs 0.4 µs for an error code. |
| Q2 | **Complete the Code output matches.** Without the cause the Cause line throws NPE. 7 scenarios through controller → service → storage, full `Caused by: NoSuchFileException` chain shown; dropping the cause loses the root type. Checked and unchecked cost the same; each chained cause adds a full stack trace. |
| Q3 | The as-found manual version leaks one file per failure (located with jdb at `ManualReport.java:27`) and hit **"Too many open files" at run 350** under `ulimit -n 256`; try-with-resources ran 2,000 times with no leak. Suppressed vs masked exceptions demonstrated; robust version completes with the bad store listed. |
| Q4 | Thread vs Runnable, run() runs on `main` (345 ms sequential) vs start() (86 ms parallel); states NEW/RUNNABLE/TIMED_WAITING/BLOCKED/WAITING/TERMINATED observed; 7 different finish orders in 10 runs; priorities had no effect on Linux; daemon killed when main ended. Pool time ≈ n/p; ~1 MB reserved / 90 KB committed per thread. |
| Q5 | **Complete the Code: `Seats sold: 10`.** Unsynchronized program showed 10 in all 10 runs (race hidden); the latch test double-booked in 14/500 natural runs and 5/10 with a payment pause; every synchronized/atomic version never did. Method lock 68 % slower than block lock; instance lock on a static counter lost 201,054 updates. |
| Q6 | **Complete the Code: 210.** `if` instead of `while`: 189/1,000 wrong sums, size down to −14; `notify` with 2 cooks + 3 students hung 200/200. Wallet deadlock reproduced 5/5 and removed by id-ordered locking (money conserved). |
| Q7 | ExecutorService + Callable + Future + ConcurrentHashMap: hand-checked set 15/15, 10,000 files 0 mismatches vs ground truth (9,590 processed, 410 failures classified). Best pool 4 on 2 CPUs (69 ms); linear speed-up with storage latency; parallel stream aborts on the first bad file. |

Screenshots are rendered from the captured console output (`tools/render_screenshots.py`).
