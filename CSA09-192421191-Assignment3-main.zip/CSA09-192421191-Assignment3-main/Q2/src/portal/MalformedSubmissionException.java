package portal;

/**
 * UNCHECKED: a programming / integration error (the client sent a request that can never be valid).
 * Callers are not forced to handle it; a single top-level handler does.
 */
public class MalformedSubmissionException extends RuntimeException {
    public MalformedSubmissionException(String message) { super(message); }
}
