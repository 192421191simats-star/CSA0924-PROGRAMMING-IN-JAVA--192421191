package portal;

import java.time.LocalDateTime;

public record Submission(String studentId, String course, LocalDateTime submittedAt, String fileName, long sizeKb) { }
