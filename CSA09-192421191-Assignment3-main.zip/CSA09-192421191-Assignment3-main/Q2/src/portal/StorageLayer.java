package portal;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** Storage layer: writes the answer file. Throws only SubmissionStorageException (checked). */
public class StorageLayer {
    public enum Mode { OK, QUOTA, NO_DIR }

    private final Path root;
    private final long quotaKb;
    private Mode mode = Mode.OK;
    private boolean keepCause = true;                       // switch used to demonstrate lost causes

    public StorageLayer(Path root, long quotaKb) { this.root = root; this.quotaKb = quotaKb; }
    public void setMode(Mode m) { mode = m; }
    public void setKeepCause(boolean k) { keepCause = k; }

    public Path save(Submission s) throws SubmissionStorageException {
        Path dir = mode == Mode.NO_DIR ? root.resolve("missing-folder") : root.resolve(s.course());
        Path target = dir.resolve(s.studentId() + "_" + s.fileName());
        try {
            if (mode != Mode.NO_DIR) Files.createDirectories(dir);
            if (mode == Mode.QUOTA || s.sizeKb() > quotaKb) throw new IOException("Disk quota exceeded");
            Files.writeString(target, "answer bytes: " + s.sizeKb() + " KB", StandardCharsets.UTF_8);   // real I/O
            return target;
        } catch (IOException e) {
            String msg = "Could not store " + s.fileName() + " for " + s.studentId() + " at " + target;
            if (keepCause) throw new SubmissionStorageException(msg, e);      // chained: root cause kept
            throw new SubmissionStorageException(msg, null);                  // ANTI-PATTERN: cause dropped
        }
    }
}
