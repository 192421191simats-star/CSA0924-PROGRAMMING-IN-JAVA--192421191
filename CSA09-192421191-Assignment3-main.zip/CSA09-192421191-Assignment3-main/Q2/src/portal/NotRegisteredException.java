package portal;

/** Checked: the student exists but is not registered for this course - recoverable by the exam cell. */
public class NotRegisteredException extends ExamException {
    public NotRegisteredException(String student, String course) {
        super("Student " + student + " is not registered for " + course,
              "You are not registered for " + course + ". Please contact the examination cell.");
    }
}
