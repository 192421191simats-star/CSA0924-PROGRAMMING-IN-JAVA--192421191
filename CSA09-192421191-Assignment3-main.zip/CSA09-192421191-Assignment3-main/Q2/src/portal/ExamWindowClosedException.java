package portal;

import java.time.LocalDateTime;

/** Checked: a normal business outcome the controller must report (submission too late / too early). */
public class ExamWindowClosedException extends ExamException {
    public ExamWindowClosedException(String course, LocalDateTime at, LocalDateTime opens, LocalDateTime closes) {
        super("Submission for " + course + " at " + at + " outside window " + opens + " - " + closes,
              "The submission window for " + course + " closed at " + closes.toLocalTime() + ".");
    }
}
