package portal;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Controller layer: validates the request shape and the exam window, calls the service, and is the
 * place where checked ExamExceptions are FINALLY HANDLED and turned into a message for the student.
 */
public class SubmissionController {
    private static final Logger LOG = Logger.getLogger("portal");
    private final ExamService service;
    private final Map<String, LocalDateTime[]> windows;      // course -> {opens, closes}

    public SubmissionController(ExamService service, Map<String, LocalDateTime[]> windows) {
        this.service = service; this.windows = windows;
    }

    /** Returns the text shown to the student. */
    public String handle(Submission s) {
        if (s.studentId() == null || s.studentId().isBlank())
            throw new MalformedSubmissionException("Request has no student id: " + s);   // unchecked: a bug upstream
        try {
            LocalDateTime[] w = windows.get(s.course());
            if (s.submittedAt().isBefore(w[0]) || s.submittedAt().isAfter(w[1]))
                throw new ExamWindowClosedException(s.course(), s.submittedAt(), w[0], w[1]);
            String stored = service.submit(s);
            return "Submission received: " + stored;
        } catch (ExamException e) {
            LOG.log(Level.WARNING, "submission rejected: " + e.getMessage(), e);           // full chain for staff
            return e.getUserMessage();                                                  // safe text for student
        }
    }
}
