package portal;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;

/** Service layer: registration and file-size rules, then delegates to storage. */
public class ExamService {
    private final Set<String> registrations;                 // "student|course"
    private final Map<String, Long> maxFileKb;
    private final StorageLayer storage;

    public ExamService(Set<String> registrations, Map<String, Long> maxFileKb, StorageLayer storage) {
        this.registrations = registrations; this.maxFileKb = maxFileKb; this.storage = storage;
    }

    /** Declares the checked base type it can propagate; storage failures pass through unchanged. */
    public String submit(Submission s) throws ExamException {
        if (!registrations.contains(s.studentId() + "|" + s.course()))
            throw new NotRegisteredException(s.studentId(), s.course());
        long limit = maxFileKb.get(s.course());
        if (s.sizeKb() > limit)
            throw new AnswerFileTooLargeException(s.fileName(), s.sizeKb(), limit);
        return storage.save(s).getFileName().toString();     // SubmissionStorageException propagates up
    }
}
