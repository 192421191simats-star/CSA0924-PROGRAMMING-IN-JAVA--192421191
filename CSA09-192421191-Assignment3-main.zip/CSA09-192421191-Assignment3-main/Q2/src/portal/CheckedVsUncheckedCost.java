package portal;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Q2 alternative concept: cost of capturing a stack trace, and how chaining increases the memory
 * held by ONE exception object. Raw data -> data/q2_exception_memory.csv
 *
 * Run: java -Xmx1g -cp out portal.CheckedVsUncheckedCost
 */
public class CheckedVsUncheckedCost {
    /** Unchecked variant of the root exception: no throws clauses needed anywhere. */
    static class UncheckedExamException extends RuntimeException {
        UncheckedExamException(String m, Throwable c) { super(m, c); }
    }
    static class Quiet extends Exception {               // no stack trace captured at all
        Quiet(String m, Throwable c) { super(m, c, false, false); }
    }

    static Throwable atDepth(int depth, int kind) {
        if (depth > 0) return atDepth(depth - 1, kind);
        IOException io = kind >= 2 ? new IOException("Disk quota exceeded") : null;   // cause only where used
        return switch (kind) {
            case 0 -> new Quiet("Could not store answer02.pdf", null);                    // no trace, no cause
            case 1 -> new SubmissionStorageException("Could not store answer02.pdf", null);// trace, no cause
            case 2 -> new SubmissionStorageException("Could not store answer02.pdf", io); // trace + 1 cause
            case 3 -> new UncheckedExamException("controller", new SubmissionStorageException("storage", io)); // 2 causes
            default -> new UncheckedExamException("same as 2, unchecked", io);
        };
    }

    @SuppressWarnings("deprecation")
    static long allocated() {
        return ((com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean()).getThreadAllocatedBytes(Thread.currentThread().getId());
    }
    static long used() { for (int i = 0; i < 3; i++) System.gc(); Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }

    public static void main(String[] args) throws IOException {
        String[] names = {"no stack trace, no cause", "checked, trace, no cause", "checked, trace + IOException cause",
                "unchecked wrapping checked + IOException", "unchecked, trace + IOException cause"};
        int n = 20_000;
        Files.createDirectories(Path.of("data"));
        System.out.println("=== Creating one exception " + 30 + " frames deep: time, allocation, retained memory ===");
        System.out.printf("  %-42s %12s %14s %18s %22s%n", "exception", "median ns", "bytes alloc", "retained B (lazy)", "retained B (trace read)");
        try (PrintWriter csv = new PrintWriter("data/q2_exception_memory.csv")) {
            csv.println("exception,ns_per_create,bytes_allocated,retained_bytes_lazy,retained_bytes_materialised");
            for (int k = 0; k < 5; k++) {
                for (int w = 0; w < 20_000; w++) atDepth(30, k);                       // warm-up
                double[] runs = new double[5];
                long alloc = 0;
                for (int r = 0; r < 5; r++) {                                          // 5 runs, median reported
                    long a0 = allocated(), t0 = System.nanoTime();
                    for (int i = 0; i < n; i++) atDepth(30, k);
                    runs[r] = (System.nanoTime() - t0) / (double) n;
                    alloc = (allocated() - a0) / n;
                }
                java.util.Arrays.sort(runs);
                double ns = runs[2];
                Throwable[] keep = new Throwable[n];
                long before = used();
                for (int i = 0; i < n; i++) keep[i] = atDepth(30, k);
                long lazy = (used() - before) / n;
                for (Throwable t : keep) for (Throwable c = t; c != null; c = c.getCause()) c.getStackTrace();  // materialise
                long full = (used() - before) / n;
                System.out.printf("  %-42s %12.0f %14d %18d %22d%n", names[k], ns, alloc, lazy, full);
                csv.printf("%s,%.0f,%d,%d,%d%n", names[k], ns, alloc, lazy, full);
                if (keep.length == 1) System.out.print("");
            }
        }
        System.out.println("Raw data: data/q2_exception_memory.csv");
    }
}
