package portal;

/**
 * Checked: the storage layer TRANSLATES low-level IOExceptions into a portal-level failure,
 * keeping the original IOException as the cause (exception chaining).
 */
public class SubmissionStorageException extends ExamException {
    public SubmissionStorageException(String message, Throwable cause) {
        super(message, "Your answer could not be saved because of a server problem. "
                + "It has NOT been submitted - please try again in a few minutes.", cause);
    }
}
