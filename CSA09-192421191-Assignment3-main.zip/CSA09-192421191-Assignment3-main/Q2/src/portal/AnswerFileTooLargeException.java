package portal;

/** Checked: the student can fix it (compress the file and resubmit). */
public class AnswerFileTooLargeException extends ExamException {
    public AnswerFileTooLargeException(String file, long sizeKb, long limitKb) {
        super(file + " is " + sizeKb + " KB, limit " + limitKb + " KB",
              "Your answer file is " + sizeKb + " KB; the limit is " + limitKb + " KB. Please compress it and resubmit.");
    }
}
