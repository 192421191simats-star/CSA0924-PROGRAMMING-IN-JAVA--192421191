package portal;

/** Root of all EXPECTED portal failures. Checked: every layer must declare or handle it. */
public class ExamException extends Exception {
    private final String userMessage;     // what the student is allowed to see

    public ExamException(String message, String userMessage) { this(message, userMessage, null); }
    public ExamException(String message, String userMessage, Throwable cause) {
        super(message, cause);
        this.userMessage = userMessage;
    }
    public String getUserMessage() { return userMessage; }
}
