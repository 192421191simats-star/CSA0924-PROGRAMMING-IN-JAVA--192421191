package portal;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Handler;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

/**
 * Q2 - runs one scenario per exception through Controller -> Service -> Storage,
 * prints the test table, the full chained stack trace, and the "cause dropped" comparison.
 *
 * Compile: javac -d out $(find src -name "*.java")
 * Run    : java -cp out portal.PortalDemo input
 */
public class PortalDemo {
    public static void main(String[] args) throws IOException {
        Path in = Path.of(args.length > 0 ? args[0] : "input");
        Set<String> reg = new HashSet<>();
        for (String l : Files.readAllLines(in.resolve("registrations.csv")))
            if (!l.isBlank() && !l.startsWith("#")) { String[] p = l.split(","); reg.add(p[0] + "|" + p[1]); }
        Map<String, LocalDateTime[]> windows = new HashMap<>();
        Map<String, Long> maxKb = new HashMap<>();
        for (String l : Files.readAllLines(in.resolve("exams.csv")))
            if (!l.isBlank() && !l.startsWith("#")) {
                String[] p = l.split(",");
                windows.put(p[0], new LocalDateTime[]{LocalDateTime.parse(p[1]), LocalDateTime.parse(p[2])});
                maxKb.put(p[0], Long.parseLong(p[3]));
            }
        Path storeRoot = Files.createTempDirectory("exam-store");
        StorageLayer storage = new StorageLayer(storeRoot, 5_000);
        SubmissionController controller = new SubmissionController(new ExamService(reg, maxKb, storage), windows);

        // capture the controller's log records so we can show what staff see
        Logger log = Logger.getLogger("portal");
        log.setUseParentHandlers(false);
        final Throwable[] lastLogged = new Throwable[1];
        log.addHandler(new Handler() {
            public void publish(LogRecord r) { lastLogged[0] = r.getThrown(); }
            public void flush() { }
            public void close() { }
        });

        Files.createDirectories(Path.of("data"));
        System.out.println("=== Test table: one scenario per exception ===");
        String fmt = "%-3s %-46s %-30s %-24s %s%n";
        System.out.printf(fmt, "ID", "scenario", "exception (layer thrown)", "cause (getCause())", "message the student sees");
        System.out.println("-".repeat(190));
        Throwable chainedExample = null;
        try (PrintWriter csv = new PrintWriter("data/q2_scenarios.csv")) {
            csv.println("id,scenario,exception,cause,student_message");
            for (String l : Files.readAllLines(in.resolve("scenarios.csv"))) {
                if (l.isBlank() || l.startsWith("#")) continue;
                String[] p = l.split("\\|");
                storage.setMode(StorageLayer.Mode.valueOf(p[7]));
                lastLogged[0] = null;
                Submission s = new Submission(p[2].trim(), p[3], LocalDateTime.parse(p[4]), p[5], Long.parseLong(p[6]));
                String shown, exc, cause;
                try {
                    shown = controller.handle(s);
                } catch (RuntimeException e) {                       // top-level handler for UNCHECKED failures
                    lastLogged[0] = e;
                    shown = "Something went wrong (ref " + Integer.toHexString(e.hashCode()) + "). The exam cell has been notified.";
                }
                Throwable t = lastLogged[0];
                exc = t == null ? "-" : t.getClass().getSimpleName() + " (" + layerOf(t) + ")";
                cause = t == null || t.getCause() == null ? "-" : t.getCause().getClass().getSimpleName();
                if (p[0].equals("S6")) chainedExample = t;
                System.out.printf(fmt, p[0], p[1], exc, cause, shown);
                csv.printf("%s,\"%s\",\"%s\",%s,\"%s\"%n", p[0], p[1], exc, cause, shown.replace("\"", "'"));
            }
        }

        System.out.println("\n=== Full chained stack trace (scenario S6, as logged for staff) ===");
        chainedExample.printStackTrace(System.out);
        System.out.println("\ngetCause() walk:");
        int level = 0;
        for (Throwable c = chainedExample; c != null; c = c.getCause())
            System.out.println("  level " + level++ + ": " + c.getClass().getName() + ": " + c.getMessage());

        System.out.println("\n=== Same failure re-thrown WITHOUT its cause ===");
        storage.setKeepCause(false);
        storage.setMode(StorageLayer.Mode.NO_DIR);
        lastLogged[0] = null;
        controller.handle(new Submission("192311002", "CSA09", LocalDateTime.parse("2026-11-20T11:00"), "answer06.pdf", 100));
        lastLogged[0].printStackTrace(System.out);
        System.out.println("getCause() = " + lastLogged[0].getCause());
        System.out.println("LOST: the root-cause TYPE (NoSuchFileException = folder missing, not quota or permission),");
        System.out.println("      the operating-system message, and the 'Caused by' frames showing WHERE in java.nio it failed.");
        System.out.println("      Staff can no longer tell S5 (quota) from S6 (missing folder) - both look identical.");
        storage.setKeepCause(true);
    }

    static String layerOf(Throwable t) {
        for (StackTraceElement e : t.getStackTrace()) {
            String c = e.getClassName();
            if (c.endsWith("StorageLayer")) return "storage";
            if (c.endsWith("ExamService")) return "service";
            if (c.endsWith("SubmissionController")) return "controller";
        }
        return "?";
    }
}
