#!/usr/bin/env bash
# Assignment 3: compiles and runs every program; console output -> QN/output/<name>.txt,
# raw measurements -> QN/data/*.csv. Programs that are EXPECTED to fail (compile error, uncaught
# exception, deadlock demo, "if" variant) are run on purpose and their failure is the evidence.
# Usage: bash run_all.sh            (about 6-8 minutes)      bash run_all.sh Q3 Q6   (selected)
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
unset JAVA_TOOL_OPTIONS 2>/dev/null || true
ONLY="${*:-Q1 Q2 Q3 Q4 Q5 Q6 Q7}"

run() {   # run <folder> <output-name> <compile> <run>
  case " $ONLY " in *" $1 "*) ;; *) return ;; esac
  cd "$ROOT/$1" || exit 1
  mkdir -p output
  { echo "\$ cd $1"; [ -n "$3" ] && { echo "\$ $3"; eval "$3" 2>&1; }; echo "\$ $4"; eval "$4" 2>&1; echo "(exit code $?)"; } > "output/$2.txt"
  echo "  $1/output/$2.txt"
}

echo "Java: $(java -version 2>&1 | head -1)"
# ---------------- Q1
run Q1 AtmTestRunner      "javac -d out AtmSimulation.java AtmTestRunner.java UncaughtDemo.java ExceptionCostBenchmark.java" "java -cp out AtmTestRunner input/test_cases.csv"
run Q1 AtmInteractive     "" "echo 2500 | java -cp out AtmSimulation input/card_valid.txt"
run Q1 UncaughtDemo       "" "java -cp out UncaughtDemo < /dev/null"
run Q1 BadCatchOrder_compile "" "javac -d /tmp/badcatch compile_error_demo/BadCatchOrder.java"
run Q1 ExceptionCostBenchmark "" "java -cp out ExceptionCostBenchmark"
# ---------------- Q2
run Q2 StorageDemo        "javac -d out StorageDemo.java" "java -cp out StorageDemo"
run Q2 StorageDemo_without_cause "javac -d out_nocause no_cause_variant/StorageDemo.java" "java -cp out_nocause StorageDemo"
run Q2 PortalDemo         'javac -d out $(find src -name "*.java")' "java -cp out portal.PortalDemo input"
run Q2 ExceptionMemory    "" "java -Xmx1g -cp out portal.CheckedVsUncheckedCost"
# ---------------- Q3
run Q3 ReportDemo         'javac -g -d out $(find src -name "*.java")' "java -cp out report.ReportDemo input"
run Q3 LeakStress_V1      "" "bash -c 'ulimit -n 256; java -cp out report.LeakStress input/stores_failing V1'"
run Q3 LeakStress_V3      "" "bash -c 'ulimit -n 256; java -cp out report.LeakStress input/stores_failing V3'"
run Q3 jdb_session        "" "(while read -r c; do echo \"\$c\"; sleep 1; done < input/jdb_commands.txt) | jdb -classpath out report.DebugTarget"
# ---------------- Q4
run Q4 ThreadLab          "javac -d out ThreadLab.java DaemonDemo.java OnceOrder.java PoolVsThreads.java" "java -cp out ThreadLab input/stations.txt"
run Q4 TenSeparateRuns    "" "for i in 1 2 3 4 5 6 7 8 9 10; do echo -n \"run \$i: \"; java -cp out OnceOrder input/stations.txt; done"
run Q4 DaemonDemo         "" "java -cp out DaemonDemo"
run Q4 PoolVsThreads      "" "java -XX:NativeMemoryTracking=summary -cp out PoolVsThreads"
# ---------------- Q5
run Q5 SeatBooking_unsync_10_runs "javac -d out_unsync before_todo/SeatBooking.java" "for i in 1 2 3 4 5 6 7 8 9 10; do echo -n \"run \$i: \"; java -cp out_unsync SeatBooking; done"
run Q5 SeatBooking        "javac -d out SeatBooking.java" "java -cp out SeatBooking"
run Q5 BookingLab         "javac -d out BookingLab.java" "java -cp out BookingLab"
# ---------------- Q6
run Q6 TokenCounter       "javac -d out TokenCounter.java" "java -cp out TokenCounter"
run Q6 TokenCounter_if_variant_10_runs "javac -d out_if if_variant/TokenCounter.java" "for i in 1 2 3 4 5 6 7 8 9 10; do echo -n \"run \$i: \"; timeout 5 java -cp out_if TokenCounter || echo \"(no result within 5 s)\"; done"
run Q6 ProducerConsumerLab "javac -d out ProducerConsumerLab.java DeadlockLab.java" "java -cp out ProducerConsumerLab"
run Q6 DeadlockLab        "" "java -cp out DeadlockLab"
# ---------------- Q7
run Q7 Generate           "javac -d out *.java" "java -cp out ScoreFileGenerator work 10000 2026"
run Q7 Q7Experiments      "" "java -Xmx1g -cp out Q7Experiments input/handcheck work"
echo "Done. Graphs: python3 tools/make_graphs.py   Screenshots: python3 tools/render_screenshots.py"
