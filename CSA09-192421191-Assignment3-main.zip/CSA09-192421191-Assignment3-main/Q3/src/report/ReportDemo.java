package report;

import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;
import java.util.stream.Stream;

/**
 * Q3 - runs all versions on good and failing input, compares the reports, counts open handles,
 * demonstrates closing order and suppressed exceptions.
 *
 * Compile: javac -g -d out $(find src -name "*.java")
 * Run    : java -cp out report.ReportDemo input
 */
public class ReportDemo {

    interface Gen { Object generate(List<Path> s, Path out) throws IOException; }

    static List<Path> stores(Path dir) throws IOException {
        try (Stream<Path> s = Files.list(dir)) { return s.filter(p -> p.toString().endsWith(".csv")).sorted().toList(); }
    }

    public static void main(String[] args) throws Exception {
        Path in = Path.of(args.length > 0 ? args[0] : "input");
        Path out = Files.createDirectories(Path.of("output/reports"));
        Files.createDirectories(Path.of("logs"));
        Files.createDirectories(Path.of("data"));
        Logger log = Logger.getLogger("report");
        FileHandler fh = new FileHandler("logs/q3_report.log");
        fh.setFormatter(new SimpleFormatter());
        log.addHandler(fh);

        String[] names = {"V1 manual (as found)", "V2 manual, try-finally per resource", "V3 try-with-resources", "V4 robust (TWR + temp file + per-store catch)"};
        Gen[] gens = {ManualReport::generate, ManualReportFixed::generate, TwrReport::generate, RobustReport::generate};

        // ---------------------------------------------------------------- good input: same report?
        System.out.println("=== 1. Good input (" + stores(in.resolve("stores_good")).size() + " store files): do all versions write the same report? ===");
        String reference = null;
        for (int v = 0; v < 4; v++) {
            Path f = out.resolve("good_v" + (v + 1) + ".txt");
            gens[v].generate(stores(in.resolve("stores_good")), f);
            String text = Files.readString(f).replace("TOTAL (complete stores only)", "TOTAL");
            if (reference == null) { reference = text; System.out.print(indent(text)); }
            System.out.printf("  %-48s identical to V1: %b   handles still open: %d%n", names[v], text.equals(reference), Tracked.OPEN.get());
        }

        // ---------------------------------------------------------------- failing input: leaks
        List<Path> failing = stores(in.resolve("stores_failing"));
        System.out.println("\n=== 2. Failing input: " + failing.size() + " store files, store_04.csv line 19 has qty 'TWELVE' ===");
        System.out.printf("  %-48s %-34s %-12s %-10s %s%n", "version", "outcome", "leaked (Java)", "OS fds +", "summary file left");
        try (PrintWriter csv = new PrintWriter("data/q3_leaks.csv")) {
            csv.println("version,outcome,leaked_handles,os_fd_increase,summary_lines");
            for (int v = 0; v < 4; v++) {
                int javaBefore = Tracked.OPEN.get(), osBefore = Tracked.osOpenFiles();
                Path f = out.resolve("failing_v" + (v + 1) + ".txt");
                String outcome;
                try {
                    Object r = gens[v].generate(failing, f);
                    outcome = "completed " + (r instanceof RobustReport.Result rr ? "(failed: " + rr.failedStores() + ")" : "");
                } catch (NumberFormatException | IOException e) {
                    outcome = "aborted: " + e.getClass().getSimpleName();
                    log.warning(names[v] + " aborted; cause " + e);
                }
                int leaked = Tracked.OPEN.get() - javaBefore, os = Tracked.osOpenFiles() - osBefore;
                long lines = Files.exists(f) ? Files.readAllLines(f).size() : 0;
                String left = Files.exists(f) ? lines + " lines" + (Files.readString(f).contains("TOTAL") ? "" : " (NO TOTAL - incomplete)") : "none";
                System.out.printf("  %-48s %-34s %-12d %-10d %s%n", names[v], outcome, leaked, os, left);
                csv.printf("%s,%s,%d,%d,%d%n", names[v], outcome, leaked, os, lines);
            }
        }

        // ---------------------------------------------------------------- repeated runs
        System.out.println("\n=== 3. Same failing report generated 200 times in one long-running process ===");
        for (int v = 0; v < 3; v++) {
            int before = Tracked.osOpenFiles();
            for (int i = 0; i < 200; i++) {
                try { gens[v].generate(failing, out.resolve("repeat.txt")); } catch (NumberFormatException | IOException e) { /* expected */ }
            }
            System.gc();                              // finalisers are gone in modern Java: GC does NOT close FileReaders' fds reliably
            System.out.printf("  %-48s OS file descriptors: %d -> %d%n", names[v], before, Tracked.osOpenFiles());
        }

        // ---------------------------------------------------------------- closing order + suppressed
        System.out.println("\n=== 4. Closing order in try-with-resources ===");
        try (Res a = new Res("summary writer", false); Res b = new Res("store reader", false); Res c = new Res("audit log", false)) {
            System.out.println("    body runs");
        }
        System.out.println("\n=== 5. Suppressed exception: body fails AND close() fails ===");
        try (Res r = new Res("store reader", true)) {
            throw new NumberFormatException("For input string: \"TWELVE\"");
        } catch (NumberFormatException e) {
            System.out.println("    caught primary : " + e);
            for (Throwable s : e.getSuppressed()) System.out.println("    suppressed     : " + s);
        }
        System.out.println("  Same situation with a manual finally:");
        try {
            Res r = new Res("store reader", true);
            try { throw new NumberFormatException("For input string: \"TWELVE\""); }
            finally { r.close(); }
        } catch (Exception e) {
            System.out.println("    caught         : " + e + "   <- the real cause (TWELVE) is LOST");
        }
        fh.close();
        System.out.println("\nLog written to logs/q3_report.log ; raw data data/q3_leaks.csv");
    }

    static final class Res implements AutoCloseable {
        final String name; final boolean failOnClose;
        Res(String n, boolean f) { name = n; failOnClose = f; System.out.println("    open  " + n); }
        @Override public void close() throws java.io.IOException {
            System.out.println("    close " + name);
            if (failOnClose) throw new java.io.IOException("close failed: " + name);
        }
    }

    static String indent(String s) { return s.lines().map(l -> "      | " + l + "\n").reduce("", String::concat); }
}
