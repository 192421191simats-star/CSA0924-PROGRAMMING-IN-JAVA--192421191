package report;

import java.io.BufferedReader;
import java.io.IOException;

/** Parses one store file: date,item,qty,unitPrice. Throws NumberFormatException on a corrupt line. */
public final class StoreParser {
    private StoreParser() { }
    public static long totalPaise(BufferedReader r) throws IOException {
        long total = 0;
        String line;
        while ((line = r.readLine()) != null) {
            if (line.isBlank() || line.startsWith("#")) continue;
            String[] p = line.split(",");
            int qty = Integer.parseInt(p[2].trim());          // <-- breakpoint target: corrupt qty throws here
            long price = Long.parseLong(p[3].trim());
            total += qty * price * 100;
        }
        return total;
    }
}
