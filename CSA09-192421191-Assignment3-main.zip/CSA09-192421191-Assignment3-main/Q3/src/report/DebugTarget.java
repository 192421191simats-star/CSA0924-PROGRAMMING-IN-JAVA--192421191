package report;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

/** Q3 - small entry point used for the jdb step-through session (V1 on the failing input only). */
public class DebugTarget {
    public static void main(String[] args) throws Exception {
        List<Path> stores;
        try (Stream<Path> s = Files.list(Path.of("input/stores_failing"))) { stores = s.sorted().toList(); }
        try {
            ManualReport.generate(stores, Path.of("output/reports/debug.txt"));
        } catch (NumberFormatException e) {
            System.out.println("report aborted: " + e.getMessage() + " ; readers still open: " + Tracked.OPEN.get());
        }
    }
}
