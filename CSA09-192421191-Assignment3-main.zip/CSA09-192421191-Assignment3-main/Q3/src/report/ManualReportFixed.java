package report;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/** VERSION 2 - manual close() done correctly: one try-finally per resource (verbose but leak-free). */
public final class ManualReportFixed {
    private ManualReportFixed() { }

    public static long generate(List<Path> stores, Path summary) throws IOException {
        BufferedWriter writer = new BufferedWriter(new Tracked.Writer(summary.toString()));
        try {
            writer.write("Daily sales summary\n");
            long grand = 0;
            for (Path p : stores) {
                BufferedReader reader = new BufferedReader(new Tracked.Reader(p.toString()));
                long t;
                try {
                    t = StoreParser.totalPaise(reader);
                } finally {
                    reader.close();                              // runs even when parsing throws
                }
                writer.write(String.format("%s,%.2f%n", p.getFileName(), t / 100.0));
                grand += t;
            }
            writer.write(String.format("TOTAL,%.2f%n", grand / 100.0));
            return grand;
        } finally {
            writer.close();                                      // if this throws, it HIDES the original exception
        }
    }
}
