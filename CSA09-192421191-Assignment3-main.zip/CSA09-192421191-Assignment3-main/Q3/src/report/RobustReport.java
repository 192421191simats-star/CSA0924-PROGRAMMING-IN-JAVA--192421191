package report;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * VERSION 4 - what try-with-resources alone does NOT give:
 *   - one bad store must not abort the whole report  -> per-store catch, failures listed
 *   - no half-written summary                        -> write to a temp file, then atomic move
 *   - the operator must know which file failed       -> logging with file name and line reason
 */
public final class RobustReport {
    private static final Logger LOG = Logger.getLogger("report");
    private RobustReport() { }

    public record Result(long grandPaise, List<String> failedStores) { }

    public static Result generate(List<Path> stores, Path summary) throws IOException {
        Path tmp = summary.resolveSibling(summary.getFileName() + ".tmp");
        List<String> failed = new ArrayList<>();
        long grand = 0;
        try (BufferedWriter writer = new BufferedWriter(new Tracked.Writer(tmp.toString()))) {
            writer.write("Daily sales summary\n");
            for (Path p : stores) {
                try (BufferedReader reader = new BufferedReader(new Tracked.Reader(p.toString()))) {
                    long t = StoreParser.totalPaise(reader);
                    writer.write(String.format("%s,%.2f%n", p.getFileName(), t / 100.0));
                    grand += t;
                } catch (NumberFormatException | IOException e) {
                    LOG.warning("store file FAILED: " + p + " -> " + e);
                    failed.add(p.getFileName().toString());
                }
            }
            writer.write(String.format("TOTAL (complete stores only),%.2f%n", grand / 100.0));
            if (!failed.isEmpty()) writer.write("FAILED STORES," + String.join(";", failed) + "\n");
        }
        Files.move(tmp, summary, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        return new Result(grand, failed);
    }
}
