package report;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

/**
 * Q3 - Student A: reproduce "Too many open files". Runs the failing report repeatedly with the
 * chosen version until the OS refuses to open another file. Start with a low limit:
 *     bash -c 'ulimit -n 256; java -cp out report.LeakStress input/stores_failing V1'
 */
public class LeakStress {
    public static void main(String[] args) throws Exception {
        Path dir = Path.of(args.length > 0 ? args[0] : "input/stores_failing");
        String version = args.length > 1 ? args[1] : "V1";
        List<Path> stores;
        try (Stream<Path> s = Files.list(dir)) { stores = s.sorted().toList(); }
        Path out = Files.createDirectories(Path.of("output/reports")).resolve("stress.txt");
        System.out.println("version " + version + ", OS fds at start: " + Tracked.osOpenFiles());
        for (int run = 1; run <= 2000; run++) {
            try {
                if (version.equals("V1")) ManualReport.generate(stores, out); else TwrReport.generate(stores, out);
            } catch (NumberFormatException e) {
                // expected: the corrupt store
            } catch (java.io.IOException e) {
                System.out.println("run " + run + ": " + e);
                System.out.println("open fds at failure: " + Tracked.osOpenFiles() + ", leaked readers: " + Tracked.OPEN.get());
                return;
            }
            if (run % 50 == 0) System.out.println("run " + run + ": OS fds " + Tracked.osOpenFiles());
        }
        System.out.println("2000 runs completed, OS fds " + Tracked.osOpenFiles());
    }
}
