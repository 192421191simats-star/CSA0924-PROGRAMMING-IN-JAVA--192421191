package report;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

/** FileReader/FileWriter that count how many are currently open (evidence for leaks). */
public final class Tracked {
    private Tracked() { }
    public static final AtomicInteger OPEN = new AtomicInteger();

    public static final class Reader extends FileReader {
        private boolean closed;
        public Reader(String path) throws FileNotFoundException { super(path); OPEN.incrementAndGet(); }
        @Override public void close() throws IOException { if (!closed) { closed = true; OPEN.decrementAndGet(); } super.close(); }
    }
    public static final class Writer extends FileWriter {
        private boolean closed;
        public Writer(String path) throws IOException { super(path); OPEN.incrementAndGet(); }
        @Override public void close() throws IOException { if (!closed) { closed = true; OPEN.decrementAndGet(); } super.close(); }
    }

    /** Operating-system view: number of file descriptors this JVM holds (Linux /proc). */
    public static int osOpenFiles() {
        String[] fds = new File("/proc/self/fd").list();
        return fds == null ? -1 : fds.length;
    }
}
