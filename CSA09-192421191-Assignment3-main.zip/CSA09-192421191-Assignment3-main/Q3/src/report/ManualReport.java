package report;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/**
 * VERSION 1 - "as found": try-finally with manual close(). The finally block closes only the
 * summary writer; each store reader is closed on the happy path inside the loop.
 * BUG: if parsing throws, reader.close() (line marked LEAK) is skipped -> one handle leaks per failing run,
 *      and the half-written summary is left behind (incomplete report).
 */
public final class ManualReport {
    private ManualReport() { }

    public static long generate(List<Path> stores, Path summary) throws IOException {
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new Tracked.Writer(summary.toString()));
            writer.write("Daily sales summary\n");
            long grand = 0;
            for (Path p : stores) {
                BufferedReader reader = new BufferedReader(new Tracked.Reader(p.toString()));
                long t = StoreParser.totalPaise(reader);          // may throw NumberFormatException
                reader.close();                                  // LEAK: skipped when the line above throws
                writer.write(String.format("%s,%.2f%n", p.getFileName(), t / 100.0));
                grand += t;
            }
            writer.write(String.format("TOTAL,%.2f%n", grand / 100.0));
            return grand;
        } finally {
            if (writer != null) writer.close();                  // only the writer is guaranteed to close
        }
    }
}
