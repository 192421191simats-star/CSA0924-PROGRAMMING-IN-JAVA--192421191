package report;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Path;
import java.util.List;

/** VERSION 3 - try-with-resources: every resource is closed automatically, in reverse order of opening. */
public final class TwrReport {
    private TwrReport() { }

    public static long generate(List<Path> stores, Path summary) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new Tracked.Writer(summary.toString()))) {
            writer.write("Daily sales summary\n");
            long grand = 0;
            for (Path p : stores) {
                long t;
                try (BufferedReader reader = new BufferedReader(new Tracked.Reader(p.toString()))) {
                    t = StoreParser.totalPaise(reader);
                }                                                // reader closed here, exception or not
                writer.write(String.format("%s,%.2f%n", p.getFileName(), t / 100.0));
                grand += t;
            }
            writer.write(String.format("TOTAL,%.2f%n", grand / 100.0));
            return grand;
        }                                                        // writer closed here
    }
}
