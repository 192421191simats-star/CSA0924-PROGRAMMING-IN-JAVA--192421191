import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Random;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Q6 Part A - hostel wallet transfers (Student B's evidence):
 *   1. a pair of transfers that reliably deadlocks (detected with ThreadMXBean)
 *   2. the same pair with a consistent lock-ordering rule (lower account id first)
 *   3. stress test: 8 threads x 20,000 random transfers, money conserved
 *   4. alternative: tryLock with timeout and retry - time per transfer
 *
 * Run: java -cp out DeadlockLab
 */
public class DeadlockLab {

    static final class Wallet {
        final int id; final String owner; long balance;
        final ReentrantLock lock = new ReentrantLock();             // used only by the tryLock design
        Wallet(int id, String owner, long balance) { this.id = id; this.owner = owner; this.balance = balance; }
        @Override public String toString() { return owner + "#" + id; }
    }

    /** DEADLOCK-PRONE: locks the source first, then the destination. */
    static void transferNaive(Wallet from, Wallet to, long amt, CountDownLatch bothHoldFirstLock) {
        synchronized (from) {
            if (bothHoldFirstLock != null) {                       // make the bad interleaving certain
                bothHoldFirstLock.countDown();
                try { bothHoldFirstLock.await(); } catch (InterruptedException e) { return; }
            }
            synchronized (to) { from.balance -= amt; to.balance += amt; }
        }
    }

    /** SAFE: always lock the wallet with the smaller id first (a global order). */
    static void transferOrdered(Wallet from, Wallet to, long amt, CountDownLatch gate) {
        Wallet first = from.id < to.id ? from : to;
        Wallet second = first == from ? to : from;
        synchronized (first) {
            if (gate != null) { gate.countDown(); try { gate.await(100, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { return; } }
            synchronized (second) { from.balance -= amt; to.balance += amt; }
        }
    }

    /** ALTERNATIVE: tryLock both with a timeout; on failure release everything, back off and retry. */
    static int transferTryLock(Wallet from, Wallet to, long amt) throws InterruptedException {
        int attempts = 0;
        while (true) {
            attempts++;
            if (from.lock.tryLock(1, TimeUnit.MILLISECONDS)) {
                try {
                    if (to.lock.tryLock(1, TimeUnit.MILLISECONDS)) {
                        try { from.balance -= amt; to.balance += amt; return attempts; }
                        finally { to.lock.unlock(); }
                    }
                } finally { from.lock.unlock(); }
            }
            Thread.sleep(0, ThreadLocalRandom.current().nextInt(1000));   // random back-off breaks livelock
        }
    }

    public static void main(String[] args) throws Exception {
        Files.createDirectories(Path.of("data"));
        ThreadMXBean mx = ManagementFactory.getThreadMXBean();

        // ------------------------------------------------------------ 1. reliable deadlock
        System.out.println("=== 1. Deadlock: Arun -> Divya and Divya -> Arun at the same moment (naive locking) ===");
        for (int run = 1; run <= 5; run++) {
            Wallet arun = new Wallet(1, "Arun", 1000), divya = new Wallet(2, "Divya", 1000);
            CountDownLatch both = new CountDownLatch(2);
            Thread t1 = new Thread(() -> transferNaive(arun, divya, 100, both), "T1 Arun->Divya");
            Thread t2 = new Thread(() -> transferNaive(divya, arun, 50, both), "T2 Divya->Arun");
            t1.setDaemon(true); t2.setDaemon(true);                  // so the JVM can still exit afterwards
            t1.start(); t2.start();
            t1.join(1000); t2.join(1000);
            long[] dead = mx.findDeadlockedThreads();
            System.out.printf("  run %d: finished=%b, deadlocked threads found=%d%n", run, !t1.isAlive() && !t2.isAlive(), dead == null ? 0 : dead.length);
            if (run == 1 && dead != null)
                for (ThreadInfo ti : mx.getThreadInfo(dead, true, true))
                    System.out.printf("      %-16s state=%s, waiting for lock on %s held by \"%s\"%n", ti.getThreadName(), ti.getThreadState(),
                            ti.getLockName(), ti.getLockOwnerName());
        }

        // ------------------------------------------------------------ 2. lock ordering
        System.out.println("\n=== 2. Same pair with lock ordering (lower wallet id first) ===");
        long[] before = mx.findDeadlockedThreads();
        int stuckFromPart1 = before == null ? 0 : before.length;
        for (int run = 1; run <= 5; run++) {
            Wallet arun = new Wallet(1, "Arun", 1000), divya = new Wallet(2, "Divya", 1000);
            CountDownLatch gate = new CountDownLatch(2);
            Thread t1 = new Thread(() -> transferOrdered(arun, divya, 100, gate));
            Thread t2 = new Thread(() -> transferOrdered(divya, arun, 50, gate));
            t1.setDaemon(true); t2.setDaemon(true);
            t1.start(); t2.start(); t1.join(2000); t2.join(2000);
            long[] dead = mx.findDeadlockedThreads();
            System.out.printf("  run %d: finished=%b, NEW deadlocked threads=%d, balances Arun %d Divya %d (total %d)%n", run,
                    !t1.isAlive() && !t2.isAlive(), (dead == null ? 0 : dead.length) - stuckFromPart1, arun.balance, divya.balance, arun.balance + divya.balance);
        }

        // ------------------------------------------------------------ 3/4. stress + timing
        System.out.println("\n=== 3. Stress: 8 threads x 20,000 random transfers among 10 wallets (mean of 5 runs) ===");
        System.out.printf("  %-34s %12s %14s %14s %16s%n", "design", "finished?", "ns/transfer", "money total", "avg attempts");
        try (PrintWriter csv = new PrintWriter("data/q6_transfers.csv")) {
            csv.println("design,run,finished,ns_per_transfer,total_money,avg_attempts");
            for (int design = 0; design < 3; design++) {
                double nsSum = 0, attemptsAvg = 0; boolean allDone = true; long money = 0;
                int runs = design == 0 ? 1 : 5;
                for (int run = 1; run <= runs; run++) {
                    Wallet[] w = new Wallet[10];
                    for (int i = 0; i < 10; i++) w[i] = new Wallet(i, "W" + i, 10_000);
                    AtomicLong attempts = new AtomicLong();
                    Thread[] ts = new Thread[8];
                    final int d = design;
                    long t0 = System.nanoTime();
                    for (int k = 0; k < 8; k++) {
                        final long seed = k * 31L + run;
                        ts[k] = new Thread(() -> {
                            Random r = new Random(seed);
                            try {
                                for (int i = 0; i < 20_000; i++) {
                                    int a = r.nextInt(10), b = r.nextInt(9); if (b >= a) b++;
                                    if (d == 0) transferNaive(w[a], w[b], 1, null);
                                    else if (d == 1) transferOrdered(w[a], w[b], 1, null);
                                    else attempts.addAndGet(transferTryLock(w[a], w[b], 1));
                                }
                            } catch (InterruptedException e) { }
                        });
                        ts[k].setDaemon(true);
                        ts[k].start();
                    }
                    boolean done = true;
                    long deadline = System.currentTimeMillis() + 3_000;     // one shared 3 s deadline
                    for (Thread t : ts) { long left = deadline - System.currentTimeMillis(); if (left > 0) t.join(left); if (t.isAlive()) done = false; }
                    double ns = (System.nanoTime() - t0) / 160_000.0;
                    long total = 0; for (Wallet x : w) total += x.balance;
                    allDone &= done; money = total;
                    if (done) nsSum += ns;
                    if (design == 2) attemptsAvg += attempts.get() / 160_000.0;
                    csv.printf("%d,%d,%b,%.1f,%d,%.3f%n", design, run, done, done ? ns : -1, total, design == 2 ? attempts.get() / 160_000.0 : 1.0);
                }
                String name = design == 0 ? "naive (from, then to)" : design == 1 ? "ordered synchronized (id order)" : "tryLock(1 ms) + back-off";
                System.out.printf("  %-34s %12s %14s %14s %16s%n", name, allDone ? "yes" : "NO - deadlock",
                        allDone ? String.format("%.0f", nsSum / runs) : "-", allDone ? String.format("%,d", money) : "(stuck)",
                        design == 2 ? String.format("%.3f", attemptsAvg / runs) : "1");
            }
        }
        long[] dead = mx.findDeadlockedThreads();
        System.out.println("  deadlocked threads left in this JVM from the naive designs: " + (dead == null ? 0 : dead.length) + " (daemon threads, JVM exits anyway)");
        System.out.println("Raw data: data/q6_transfers.csv");
    }
}
