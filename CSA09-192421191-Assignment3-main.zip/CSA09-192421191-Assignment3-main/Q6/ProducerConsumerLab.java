import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Q6 Part B - mess token counter (bounded buffer, capacity 5) - Student A's evidence:
 *   1. counter size recorded over time (never > 5, never < 0)
 *   2. many trials of: while+notifyAll (correct), if+notifyAll, while+notify
 *   3. alternative: ArrayBlockingQueue(5) - time per put/take
 *
 * Compile: javac -d out ProducerConsumerLab.java
 * Run    : java -cp out ProducerConsumerLab
 */
public class ProducerConsumerLab {

    /** Bounded counter with switchable wait condition (while/if) and wake-up (notifyAll/notify). */
    static final class Counter {
        final int[] buf; int count, in, out;
        final boolean useWhile, useNotifyAll;
        final AtomicInteger minSeen = new AtomicInteger(), maxSeen = new AtomicInteger();
        PrintWriter trace;                              // optional size-over-time log
        final long t0 = System.nanoTime();

        Counter(int cap, boolean useWhile, boolean useNotifyAll) { buf = new int[cap]; this.useWhile = useWhile; this.useNotifyAll = useNotifyAll; }

        synchronized void put(int token) throws InterruptedException {
            if (useWhile) { while (count == buf.length) wait(); } else { if (count == buf.length) wait(); }
            buf[in] = token; in = (in + 1) % buf.length; count++;
            record("put", token);
            if (useNotifyAll) notifyAll(); else notify();
        }

        synchronized int take() throws InterruptedException {
            if (useWhile) { while (count == 0) wait(); } else { if (count == 0) wait(); }
            int token = buf[out]; out = (out + 1) % buf.length; count--;
            record("take", token);
            if (useNotifyAll) notifyAll(); else notify();
            return token;
        }

        private void record(String op, int token) {
            minSeen.accumulateAndGet(count, Math::min);
            maxSeen.accumulateAndGet(count, Math::max);
            if (trace != null) trace.printf("%.3f,%s,%s,%d,%d%n", (System.nanoTime() - t0) / 1e6, Thread.currentThread().getName(), op, token, count);
        }
    }

    /** One trial: P producers each put `per` tokens; C consumers share the takes. Returns {sum, hung(0/1), min, max}. */
    static long[] trial(Counter c, int producers, int consumers, int perProducer, long timeoutMs) throws InterruptedException {
        int totalTokens = producers * perProducer;
        AtomicLong sum = new AtomicLong();
        AtomicInteger taken = new AtomicInteger();
        Thread[] ts = new Thread[producers + consumers];
        for (int p = 0; p < producers; p++) {
            final int base = p * perProducer;
            ts[p] = new Thread(() -> {
                try { for (int t = 1; t <= perProducer; t++) c.put(base + t); } catch (InterruptedException e) { }
            }, "cook-" + (p + 1));
        }
        for (int k = 0; k < consumers; k++) {
            ts[producers + k] = new Thread(() -> {
                try {
                    while (taken.getAndIncrement() < totalTokens) sum.addAndGet(c.take());
                } catch (InterruptedException e) { }
            }, "student-" + (k + 1));
        }
        for (Thread t : ts) { t.setDaemon(true); t.start(); }
        long deadline = System.currentTimeMillis() + timeoutMs;
        boolean hung = false;
        for (Thread t : ts) {
            long left = deadline - System.currentTimeMillis();
            if (left > 0) t.join(left);
            if (t.isAlive()) hung = true;
        }
        if (hung) for (Thread t : ts) t.interrupt();
        return new long[]{sum.get(), hung ? 1 : 0, c.minSeen.get(), c.maxSeen.get()};
    }

    public static void main(String[] args) throws Exception {
        Files.createDirectories(Path.of("data"));

        // ------------------------------------------------------------ 1. size over time
        System.out.println("=== 1. Counter size over time (correct version: while + notifyAll), 1 cook, 2 students, 20 tokens ===");
        Counter traced = new Counter(5, true, true);
        try (PrintWriter tr = new PrintWriter("data/q6_counter_trace.csv")) {
            tr.println("ms,thread,op,token,count_after");
            traced.trace = tr;
            long[] r = trial(traced, 1, 2, 20, 5_000);
            System.out.printf("  sum %d (expected 210), size range observed [%d, %d], hung=%b; every operation logged in data/q6_counter_trace.csv%n",
                    r[0], r[2], r[3], r[1] == 1);
        }
        long lines = Files.readAllLines(Path.of("data/q6_counter_trace.csv")).size() - 1;
        System.out.println("  " + lines + " operations recorded; first 12:");
        Files.readAllLines(Path.of("data/q6_counter_trace.csv")).stream().skip(1).limit(12).forEach(l -> System.out.println("    " + l));

        // ------------------------------------------------------------ 2. variants over many trials
        System.out.println("\n=== 2. Variants over many trials (a trial still running after 300 ms = 'hung'; a correct trial takes a few ms) ===");
        System.out.printf("  %-28s %-34s %7s %10s %8s %12s%n", "variant", "setup", "trials", "wrong sum", "hung", "size range");
        Object[][] cases = {
                {"while + notifyAll (correct)", true, true, 1, 2, 20, 1_000},
                {"if + notifyAll", false, true, 1, 2, 20, 1_000},
                {"while + notify", true, false, 1, 2, 20, 1_000},
                {"while + notifyAll (correct)", true, true, 2, 3, 30, 200},
                {"if + notifyAll", false, true, 2, 3, 30, 200},
                {"while + notify", true, false, 2, 3, 30, 200},
        };
        try (PrintWriter csv = new PrintWriter("data/q6_variants.csv")) {
            csv.println("variant,producers,consumers,trial,sum,expected,hung,min_size,max_size");
            for (Object[] cs : cases) {
                int prod = (int) cs[3], cons = (int) cs[4], per = (int) cs[5], trials = (int) cs[6];
                int cap = prod == 1 ? 5 : 1;
                long expected = 0;
                for (int p = 0; p < prod; p++) for (int t = 1; t <= per; t++) expected += p * per + t;
                int wrong = 0, hung = 0; long min = 0, max = 0;
                for (int k = 1; k <= trials; k++) {
                    long[] r = trial(new Counter(cap, (boolean) cs[1], (boolean) cs[2]), prod, cons, per, 300);
                    if (r[1] == 1) hung++; else if (r[0] != expected) wrong++;
                    min = Math.min(min, r[2]); max = Math.max(max, r[3]);
                    csv.printf("%s,%d,%d,%d,%d,%d,%d,%d,%d%n", cs[0], prod, cons, k, r[0], expected, r[1], r[2], r[3]);
                }
                System.out.printf("  %-28s %-34s %7d %10d %8d %12s%n", cs[0],
                        prod + " cook(s), " + cons + " students, capacity " + cap, trials, wrong, hung, "[" + min + ", " + max + "]");
            }
        }

        // ------------------------------------------------------------ 3. ArrayBlockingQueue
        System.out.println("\n=== 3. Hand-written counter vs ArrayBlockingQueue(5): 1 cook, 2 students, 200,000 tokens ===");
        try (PrintWriter csv = new PrintWriter("data/q6_queue_timing.csv")) {
            csv.println("design,run,ns_per_token");
            for (int design = 0; design < 2; design++) {
                for (int w = 0; w < 2; w++) runThroughput(design, 50_000);
                double total = 0;
                for (int r = 1; r <= 5; r++) { double ns = runThroughput(design, 200_000); total += ns; csv.printf("%s,%d,%.1f%n", design == 0 ? "wait/notifyAll" : "ArrayBlockingQueue", r, ns); }
                System.out.printf("  %-26s %8.1f ns per token (put + take), mean of 5 runs%n", design == 0 ? "wait()/notifyAll() counter" : "ArrayBlockingQueue<Integer>", total / 5);
            }
        }
        System.out.println("Raw data: data/q6_counter_trace.csv, data/q6_variants.csv, data/q6_queue_timing.csv");
    }

    static double runThroughput(int design, int n) throws InterruptedException {
        Counter c = new Counter(5, true, true);
        BlockingQueue<Integer> q = new ArrayBlockingQueue<>(5);
        AtomicLong sum = new AtomicLong();
        AtomicInteger taken = new AtomicInteger();
        Thread cook = new Thread(() -> {
            try { for (int t = 1; t <= n; t++) { if (design == 0) c.put(t); else q.put(t); } } catch (InterruptedException e) { }
        });
        Thread[] st = new Thread[2];
        for (int k = 0; k < 2; k++) st[k] = new Thread(() -> {
            try { while (taken.getAndIncrement() < n) sum.addAndGet(design == 0 ? c.take() : q.take()); } catch (InterruptedException e) { }
        });
        long t0 = System.nanoTime();
        cook.start(); for (Thread t : st) t.start();
        cook.join(); for (Thread t : st) t.join();
        if (sum.get() != (long) n * (n + 1) / 2) throw new IllegalStateException("lost tokens");
        return (System.nanoTime() - t0) / (double) n;
    }
}
