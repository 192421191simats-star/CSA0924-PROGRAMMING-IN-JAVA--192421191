// Q6 - experiment: the completed TokenCounter with "while" changed to "if" in both methods.
// Compile: javac -d out_if if_variant/TokenCounter.java   Run several times: timeout 5 java -cp out_if TokenCounter
public class TokenCounter {
    private final int[] buffer = new int[5];        // the counter holds at most 5 tokens
    private int count = 0, in = 0, out = 0;

    public synchronized void put(int token) throws InterruptedException {
        // TODO 1: Wait while the counter is full, add the token at position in, then
        //   wake waiting threads
        if (count == buffer.length) wait();         // "if" instead of "while" (experiment)
        buffer[in] = token;
        in = (in + 1) % buffer.length;              // circular buffer
        count++;
        notifyAll();                                // wake consumers (and anyone else waiting)
    }

    public synchronized int take() throws InterruptedException {
        // TODO 2: Wait while the counter is empty, remove the token at position out,
        //   wake waiting threads and return the token
        if (count == 0) wait();                     // "if" instead of "while" (experiment)
        int token = buffer[out];
        out = (out + 1) % buffer.length;
        count--;
        notifyAll();                                // wake the producer waiting for space
        return token;
    }

    public static void main(String[] args) throws InterruptedException {
        TokenCounter counter = new TokenCounter();
        int[] collected = new int[2];
        Thread cook = new Thread(() -> {
            try {
                for (int t = 1; t <= 20; t++) counter.put(t);
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        });
        Thread[] students = new Thread[2];
        for (int s = 0; s < 2; s++) {
            final int id = s;
            students[s] = new Thread(() -> {
                try {
                    for (int k = 0; k < 10; k++) collected[id] += counter.take();
                } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            });
        }
        cook.start(); for (Thread t : students) t.start();
        cook.join(); for (Thread t : students) t.join();
        System.out.println("Sum of tokens collected: " + (collected[0] + collected[1])
                + " (expected 210)");
    }
}
