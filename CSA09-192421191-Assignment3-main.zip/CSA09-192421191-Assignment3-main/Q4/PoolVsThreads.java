import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.management.ObjectName;

/**
 * Q4 alternative concept: ExecutorService with a fixed pool vs creating Thread objects yourself.
 *  (a) completion time for n scripts with p threads (expected about n/p x time-per-script)
 *  (b) native memory per thread (thread stacks) measured with Native Memory Tracking
 *
 * Run: java -XX:NativeMemoryTracking=summary -cp out PoolVsThreads
 */
public class PoolVsThreads {

    static long scan(int script) throws InterruptedException { return ThreadLab.scanOne(script, 2); }

    /** Executor version: one task per script, p worker threads reused for all of them. */
    static double withPool(int n, int p) throws Exception {
        ExecutorService pool = Executors.newFixedThreadPool(p);
        long t0 = System.nanoTime();
        List<Future<Long>> fs = new ArrayList<>(n);
        for (int i = 0; i < n; i++) { final int s = i; fs.add(pool.submit(() -> scan(s))); }
        long sink = 0;
        for (Future<Long> f : fs) sink += f.get();
        double ms = (System.nanoTime() - t0) / 1e6;
        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.SECONDS);
        if (sink == 42) System.out.print("");
        return ms;
    }

    /** Manual version: p threads created by hand, each given a fixed slice of n/p scripts. */
    static double withThreads(int n, int p) throws Exception {
        Thread[] ts = new Thread[p];
        long t0 = System.nanoTime();
        for (int k = 0; k < p; k++) {
            final int from = k * n / p, to = (k + 1) * n / p;
            ts[k] = new Thread(() -> {
                try { for (int s = from; s < to; s++) scan(s); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            });
            ts[k].start();
        }
        for (Thread t : ts) t.join();
        return (System.nanoTime() - t0) / 1e6;
    }

    /** "Thread" line of NMT: reserved and committed KB. */
    static long[] nmtThread() throws Exception {
        String out = (String) ManagementFactory.getPlatformMBeanServer().invoke(
                new ObjectName("com.sun.management:type=DiagnosticCommand"), "vmNativeMemory",
                new Object[]{new String[]{"summary"}}, new String[]{String[].class.getName()});
        Matcher m = Pattern.compile("-\\s+Thread \\(reserved=(\\d+)KB, committed=(\\d+)KB\\)").matcher(out);
        if (!m.find()) return new long[]{-1, -1};
        return new long[]{Long.parseLong(m.group(1)), Long.parseLong(m.group(2))};
    }

    public static void main(String[] args) throws Exception {
        Files.createDirectories(Path.of("data"));
        int n = 400;
        System.out.println("=== (a) " + n + " scripts, 2 ms scanner wait + CPU check each; mean of 5 runs ===");
        System.out.printf("  %-4s %16s %18s %18s%n", "p", "expected ~n/p*t", "ExecutorService ms", "manual threads ms");
        double single = 0;
        try (PrintWriter csv = new PrintWriter("data/q4_pool.csv")) {
            csv.println("p,run,executor_ms,manual_ms");
            for (int w = 0; w < 2; w++) { withPool(100, 4); withThreads(100, 4); }
            for (int p : new int[]{1, 2, 4, 8, 16}) {
                double e = 0, m = 0;
                for (int r = 1; r <= 5; r++) {
                    double a = withPool(n, p), b = withThreads(n, p);
                    e += a; m += b;
                    csv.printf("%d,%d,%.2f,%.2f%n", p, r, a, b);
                }
                e /= 5; m /= 5;
                if (p == 1) single = e;
                System.out.printf("  %-4d %16.0f %18.1f %18.1f%n", p, single / p, e, m);
            }
        }

        System.out.println("\n=== (b) Native memory of threads (Native Memory Tracking 'Thread' category) ===");
        long[] base = nmtThread();
        if (base[0] < 0) { System.out.println("  run with -XX:NativeMemoryTracking=summary to measure"); return; }
        int k = 500;
        CountDownLatch hold = new CountDownLatch(1);
        Thread[] parked = new Thread[k];
        for (int i = 0; i < k; i++) {
            parked[i] = new Thread(() -> { try { hold.await(); } catch (InterruptedException e) { } });
            parked[i].start();
        }
        Thread.sleep(200);
        long[] with = nmtThread();
        hold.countDown();
        for (Thread t : parked) t.join();
        System.out.printf("  %d idle threads: reserved +%,d KB (%.0f KB each), committed +%,d KB (%.0f KB each)%n",
                k, with[0] - base[0], (with[0] - base[0]) / (double) k, with[1] - base[1], (with[1] - base[1]) / (double) k);
        System.out.println("  default -Xss stack: reserved address space per thread; only touched pages are committed");
        System.out.println("Raw data: data/q4_pool.csv");
    }
}
