/**
 * Q4 - Student B: Station-4 is a daemon thread with a long batch. main() joins only the three
 * user threads and returns; the JVM then exits even though the daemon is still scanning.
 *
 * Run: java -cp out DaemonDemo
 */
public class DaemonDemo {
    public static void main(String[] args) throws InterruptedException {
        Thread[] users = new Thread[3];
        for (int i = 0; i < 3; i++) {
            final int id = i + 1;
            users[i] = new Thread(() -> {
                for (int s = 1; s <= 10; s++) sleep(5);
                System.out.println("Station-" + id + " (user thread) finished 10 scripts");
            }, "Station-" + id);
        }
        Thread daemon = new Thread(() -> {
            for (int s = 1; s <= 100; s++) {
                sleep(5);
                if (s % 5 == 0) System.out.println("Station-4 (daemon) scanned " + s + " / 100");
            }
            System.out.println("Station-4 (daemon) finished 100 scripts");      // never printed
        }, "Station-4");
        daemon.setDaemon(true);                                                     // must be set BEFORE start()
        daemon.start();
        for (Thread t : users) t.start();
        for (Thread t : users) t.join();
        System.out.println("main() ends now; daemon alive = " + daemon.isAlive());
    }

    static void sleep(int ms) {
        try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
