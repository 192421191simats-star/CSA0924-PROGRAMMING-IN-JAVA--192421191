import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Q4 - Parallel answer-script scanning: Thread vs Runnable, start/sleep/join/isAlive,
 * run() vs start(), life-cycle states, finish-order and priority experiments.
 *
 * Compile: javac -d out ThreadLab.java DaemonDemo.java OnceOrder.java PoolVsThreads.java
 * Run    : java -cp out ThreadLab input/stations.txt
 */
public class ThreadLab {

    record Station(String name, int scripts, int msPerScript) { }

    /** Simulated scanning of one script: a short sleep (scanner I/O) plus some CPU work (image check). */
    static long scanOne(int script, int ms) throws InterruptedException {
        Thread.sleep(ms);
        long h = script;
        for (int i = 0; i < 20_000; i++) h = h * 31 + i;
        return h;
    }

    // ------------------------------------------------------------ way 1: extend Thread
    static class ScannerStationThread extends Thread {
        private final Station s;
        volatile int scanned;
        ScannerStationThread(Station s) { super(s.name()); this.s = s; }   // the thread IS the station
        @Override public void run() {
            try {
                for (int i = 1; i <= s.scripts(); i++) { scanOne(i, s.msPerScript()); scanned++; }
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    // ------------------------------------------------------------ way 2: implement Runnable
    static class ScannerStationTask implements Runnable {
        private final Station s;
        private final ConcurrentLinkedQueue<String> finishOrder;
        private final Object printer;                                     // shared "report printer"
        volatile int scanned;
        ScannerStationTask(Station s, ConcurrentLinkedQueue<String> finishOrder, Object printer) {
            this.s = s; this.finishOrder = finishOrder; this.printer = printer;
        }
        @Override public void run() {
            try {
                for (int i = 1; i <= s.scripts(); i++) {
                    scanOne(i, s.msPerScript());
                    scanned++;
                    if (i % 10 == 0 && printer != null)
                        synchronized (printer) { Thread.sleep(1); }               // others BLOCK while printing
                }
                finishOrder.add(s.name());
            } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        }
    }

    static List<Station> load(String file) throws IOException {
        List<Station> l = new ArrayList<>();
        for (String line : Files.readAllLines(Path.of(file)))
            if (!line.isBlank() && !line.startsWith("#")) {
                String[] p = line.split(",");
                l.add(new Station(p[0], Integer.parseInt(p[1].trim()), Integer.parseInt(p[2].trim())));
            }
        return l;
    }

    /** One run with Runnable tasks; returns the finish order. */
    static List<String> runOnce(List<Station> st, int[] priorities) throws InterruptedException {
        ConcurrentLinkedQueue<String> order = new ConcurrentLinkedQueue<>();
        List<Thread> ts = new ArrayList<>();
        for (int i = 0; i < st.size(); i++) {
            Thread t = new Thread(new ScannerStationTask(st.get(i), order, null), st.get(i).name());
            if (priorities != null) t.setPriority(priorities[i]);
            ts.add(t);
        }
        for (Thread t : ts) t.start();
        for (Thread t : ts) t.join();
        return new ArrayList<>(order);
    }

    public static void main(String[] args) throws Exception {
        List<Station> st = load(args.length > 0 ? args[0] : "input/stations.txt");
        Files.createDirectories(Path.of("data"));
        int expectedTotal = st.stream().mapToInt(Station::scripts).sum();

        // ------------------------------------------------ 1. extend Thread, start/isAlive/join
        System.out.println("=== 1. Stations as subclasses of Thread ===");
        List<ScannerStationThread> threads = new ArrayList<>();
        for (Station s : st) threads.add(new ScannerStationThread(s));
        long t0 = System.nanoTime();
        for (ScannerStationThread t : threads) t.start();
        Thread.sleep(20);
        for (ScannerStationThread t : threads)
            System.out.printf("  after 20 ms: %s isAlive=%b scanned so far=%d state=%s%n", t.getName(), t.isAlive(), t.scanned, t.getState());
        for (ScannerStationThread t : threads) t.join();                 // main WAITS for each station
        int total = threads.stream().mapToInt(t -> t.scanned).sum();
        System.out.printf("  after join(): all alive=%b, total scanned=%d (expected %d) in %.0f ms%n",
                threads.stream().anyMatch(Thread::isAlive), total, expectedTotal, (System.nanoTime() - t0) / 1e6);

        // ------------------------------------------------ 2. implement Runnable
        System.out.println("\n=== 2. Stations as Runnable tasks given to Thread objects ===");
        t0 = System.nanoTime();
        List<String> order = runOnce(st, null);
        System.out.printf("  finish order %s, %.0f ms%n", order, (System.nanoTime() - t0) / 1e6);

        // ------------------------------------------------ 3. run() instead of start()
        System.out.println("\n=== 3. Calling run() instead of start() ===");
        List<String> who = Collections.synchronizedList(new ArrayList<>());
        Runnable probe = () -> who.add(Thread.currentThread().getName());
        Thread a = new Thread(probe, "Station-A");
        t0 = System.nanoTime();
        a.run();                                                          // plain method call
        for (Station s : st) new ScannerStationThread(s).run();
        double runMs = (System.nanoTime() - t0) / 1e6;
        System.out.printf("  run(): code executed by thread '%s'; Station-A state afterwards %s; 4 stations took %.0f ms (sequential)%n",
                who.get(0), a.getState(), runMs);
        Thread b = new Thread(probe, "Station-B");
        b.start(); b.join();
        t0 = System.nanoTime();
        List<ScannerStationThread> par = new ArrayList<>();
        for (Station s : st) { ScannerStationThread x = new ScannerStationThread(s); par.add(x); x.start(); }
        for (Thread x : par) x.join();
        System.out.printf("  start(): code executed by thread '%s'; 4 stations took %.0f ms (parallel)%n", who.get(1), (System.nanoTime() - t0) / 1e6);

        // ------------------------------------------------ 4. life-cycle states observed
        System.out.println("\n=== 4. Life-cycle states sampled every 1 ms (with a shared report printer lock) ===");
        Object printer = new Object();
        ConcurrentLinkedQueue<String> fo = new ConcurrentLinkedQueue<>();
        List<Thread> lt = new ArrayList<>();
        for (Station s : st) lt.add(new Thread(new ScannerStationTask(s, fo, printer), s.name()));
        Thread mainThread = Thread.currentThread();
        Map<String, Map<Thread.State, Integer>> seen = new LinkedHashMap<>();
        for (Thread t : lt) { seen.put(t.getName(), new LinkedHashMap<>()); seen.get(t.getName()).merge(t.getState(), 1, Integer::sum); }
        seen.put("main", new LinkedHashMap<>());
        AtomicInteger stop = new AtomicInteger();
        Thread monitor = new Thread(() -> {
            while (stop.get() == 0) {
                for (Thread t : lt) seen.get(t.getName()).merge(t.getState(), 1, Integer::sum);
                seen.get("main").merge(mainThread.getState(), 1, Integer::sum);
                try { Thread.sleep(1); } catch (InterruptedException e) { return; }
            }
        }, "monitor");
        monitor.start();
        for (Thread t : lt) t.start();
        for (Thread t : lt) t.join();
        Thread.sleep(5);
        stop.set(1); monitor.join();
        for (Thread t : lt) seen.get(t.getName()).merge(t.getState(), 1, Integer::sum);
        seen.forEach((k, v) -> System.out.printf("  %-10s %s%n", k, v));
        System.out.println("  (counts = number of samples in each state; NEW recorded before start())");

        // ------------------------------------------------ 5. finish order over 10 runs
        System.out.println("\n=== 5. Finish order over 10 runs (equal work per station) ===");
        try (PrintWriter csv = new PrintWriter("data/q4_finish_order.csv")) {
            csv.println("experiment,run,first,second,third,fourth");
            Map<String, Integer> firsts = new LinkedHashMap<>();
            for (int r = 1; r <= 10; r++) {
                List<String> o = runOnce(st, null);
                firsts.merge(o.get(0), 1, Integer::sum);
                System.out.printf("  run %2d: %s%n", r, o);
                csv.printf("default,%d,%s%n", r, String.join(",", o));
            }
            System.out.println("  times each station finished FIRST: " + firsts);

            // ------------------------------------------------ 6. priorities
            System.out.println("\n=== 6. Priorities 1, 5, 5, 10 (Station-4 highest, Station-1 lowest), 10 runs ===");
            int[] pr = {Thread.MIN_PRIORITY, Thread.NORM_PRIORITY, Thread.NORM_PRIORITY, Thread.MAX_PRIORITY};
            Map<String, Integer> firstsP = new LinkedHashMap<>(), lastsP = new LinkedHashMap<>();
            for (int r = 1; r <= 10; r++) {
                List<String> o = runOnce(st, pr);
                firstsP.merge(o.get(0), 1, Integer::sum);
                lastsP.merge(o.get(3), 1, Integer::sum);
                System.out.printf("  run %2d: %s%n", r, o);
                csv.printf("priorities,%d,%s%n", r, String.join(",", o));
            }
            System.out.println("  finished FIRST: " + firstsP + "   finished LAST: " + lastsP);
        }
        System.out.println("  CPUs available to the JVM: " + Runtime.getRuntime().availableProcessors()
                + "  (raw data: data/q4_finish_order.csv)");
    }
}
