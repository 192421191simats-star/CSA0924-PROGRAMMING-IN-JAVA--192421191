import java.util.List;

/** Q4 - one run of four stations per JVM start, printing the finish order (used to run the program 10 times). */
public class OnceOrder {
    public static void main(String[] args) throws Exception {
        List<String> o = ThreadLab.runOnce(ThreadLab.load(args.length > 0 ? args[0] : "input/stations.txt"), null);
        System.out.println(String.join(" -> ", o));
    }
}
