import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Q7 - generates the semester's answer-script score files with injected faults and writes the
 * ground truth (which file has which fault) so the processor's summary can be checked exactly.
 *
 * Run: java -cp out ScoreFileGenerator work 10000 2026
 *  -> work/scripts/*.txt, work/manifest.txt, work/ground_truth.csv
 */
public class ScoreFileGenerator {
    static final String[] COURSES = {"CSA09", "MAT12", "PHY03", "ENG01", "ECE07"};

    public static void main(String[] args) throws IOException {
        Path root = Path.of(args.length > 0 ? args[0] : "work");
        int n = args.length > 1 ? Integer.parseInt(args[1]) : 10_000;
        long seed = args.length > 2 ? Long.parseLong(args[2]) : 2026;
        Path dir = Files.createDirectories(root.resolve("scripts"));
        try (var s = Files.list(dir)) { for (Path p : s.toList()) Files.delete(p); }
        Random rnd = new Random(seed);

        // fault plan: 1.5% corrupt marks, 0.5% wrong field count, 0.5% out of range, 0.3% empty,
        //             1% missing, 0.2% duplicate regNo, 0.1% missing name line (triggers a parser BUG)
        List<String> plan = new ArrayList<>();
        int[] counts = {(int) (n * 0.015), (int) (n * 0.005), (int) (n * 0.005), (int) (n * 0.003), (int) (n * 0.01), (int) (n * 0.002), (int) (n * 0.001)};
        String[] kinds = {"CORRUPT_MARKS", "WRONG_FIELD_COUNT", "OUT_OF_RANGE", "EMPTY", "MISSING", "DUPLICATE", "NO_NAME"};
        for (int k = 0; k < kinds.length; k++) for (int i = 0; i < counts[k]; i++) plan.add(kinds[k]);
        while (plan.size() < n) plan.add("OK");
        Collections.shuffle(plan, rnd);

        try (PrintWriter manifest = new PrintWriter(root.resolve("manifest.txt").toFile());
             PrintWriter truth = new PrintWriter(root.resolve("ground_truth.csv").toFile())) {
            truth.println("file,fault");
            for (int i = 0; i < n; i++) {
                String file = String.format("script_%05d.txt", i);
                String reg = String.valueOf(192_300_000 + i);
                String kind = plan.get(i);
                if (kind.equals("DUPLICATE")) {                          // reuse the regNo of an earlier VALID file
                    int j;
                    do { j = rnd.nextInt(Math.max(1, i)); } while (!plan.get(j).equals("OK"));
                    reg = String.valueOf(192_300_000 + j);
                }
                manifest.println(file);
                truth.printf("%s,%s%n", file, kind);
                if (kind.equals("MISSING")) continue;                      // listed but never written
                int[] marks = new int[5];
                for (int m = 0; m < 5; m++) marks[m] = 38 + rnd.nextInt(63);      // 38..100: most students pass
                StringBuilder sb = new StringBuilder();
                if (!kind.equals("EMPTY")) {
                    sb.append("regNo=").append(reg).append('\n');
                    if (!kind.equals("NO_NAME")) sb.append("name=Student ").append(i).append('\n');
                    sb.append("course=").append(COURSES[i % COURSES.length]).append('\n');
                    String ms = switch (kind) {
                        case "CORRUPT_MARKS" -> marks[0] + "," + marks[1] + ",7O," + marks[3] + "," + marks[4];   // letter O
                        case "WRONG_FIELD_COUNT" -> marks[0] + "," + marks[1] + "," + marks[2];
                        case "OUT_OF_RANGE" -> marks[0] + "," + marks[1] + ",134," + marks[3] + "," + marks[4];
                        default -> marks[0] + "," + marks[1] + "," + marks[2] + "," + marks[3] + "," + marks[4];
                    };
                    sb.append("marks=").append(ms).append('\n');
                }
                Files.writeString(dir.resolve(file), sb.toString());
            }
        }
        System.out.printf("generated %,d manifest entries in %s (seed %d)%n", n, dir, seed);
        for (int k = 0; k < kinds.length; k++) System.out.printf("  injected %-18s %d%n", kinds[k], counts[k]);
    }
}
