import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.lang.management.ManagementFactory;

/**
 * Q7 - Stage 3 evidence: hand-checked set, 10,000-file run verified against the ground truth,
 * timing with pools of 1, 2, 4, 8 (and 16) threads, and the alternative designs.
 *
 * Run: java -cp out ScoreFileGenerator work 10000 2026
 *      java -Xmx1g -cp out Q7Experiments input/handcheck work
 */
public class Q7Experiments {

    public static void main(String[] args) throws Exception {
        Path hand = Path.of(args.length > 0 ? args[0] : "input/handcheck");
        Path work = Path.of(args.length > 1 ? args[1] : "work");
        Files.createDirectories(Path.of("data"));

        // ======================================================= 1. hand-checked set
        System.out.println("=== 1. Hand-checked set (" + hand + ") with a pool of 4 threads ===");
        ResultProcessor.Summary hs = ResultProcessor.process(hand.resolve("scripts"), ResultProcessor.readManifest(hand.resolve("manifest.txt")), 4, 0, 2_000);
        for (ResultProcessor.StudentResult r : hs.results.values())
            System.out.printf("  %-8s %-10s %-24s total %3d  %5.1f%%  grade %-2s %s%n", r.file(), r.regNo(), java.util.Arrays.toString(r.marks()),
                    r.total(), r.percent(), r.grade(), r.pass() ? "PASS" : "FAIL");
        for (ResultProcessor.Failure f : hs.failures) System.out.printf("  %-8s FAILED %-18s %s%n", f.file(), f.type(), f.detail());
        Map<String, String> got = new HashMap<>();
        got.put("manifest", "" + hs.manifest); got.put("processed", "" + hs.processed); got.put("failed", "" + hs.failures.size());
        got.put("PASS", "" + hs.results.values().stream().filter(ResultProcessor.StudentResult::pass).count());
        got.put("FAIL", "" + hs.results.values().stream().filter(r -> !r.pass()).count());
        for (ResultProcessor.Failure f : hs.failures) got.put("failure:" + f.type(), f.file());
        for (ResultProcessor.StudentResult r : hs.results.values()) got.put("grade:" + r.file(), r.grade());
        int ok = 0, total = 0;
        System.out.println("  check against expected_summary.txt (worked out by hand):");
        for (String l : Files.readAllLines(hand.resolve("expected_summary.txt"))) {
            if (l.isBlank() || l.startsWith("#")) continue;
            String[] kv = l.split("=", 2);
            boolean m = kv[1].equals(got.get(kv[0]));
            total++; if (m) ok++;
            System.out.printf("    %-24s expected %-8s got %-8s %s%n", kv[0], kv[1], got.get(kv[0]), m ? "OK" : "MISMATCH");
        }
        System.out.printf("  %d / %d hand-checked items match; summary complete (processed + failed == manifest): %b%n", ok, total, hs.complete());

        // ======================================================= 2. full run verified against ground truth
        List<String> manifest = ResultProcessor.readManifest(work.resolve("manifest.txt"));
        Map<String, String> truth = new HashMap<>();
        for (String l : Files.readAllLines(work.resolve("ground_truth.csv")).subList(1, manifest.size() + 1)) { String[] p = l.split(","); truth.put(p[0], p[1]); }
        System.out.println("\n=== 2. Full run: " + manifest.size() + " manifest entries, pool of 4, checked file-by-file against the ground truth ===");
        ResultProcessor.Summary full = ResultProcessor.process(work.resolve("scripts"), manifest, 4, 0, 5_000);
        Map<String, String> observed = new HashMap<>();
        for (String f : full.results.keySet()) observed.put(f, "OK");
        for (ResultProcessor.Failure f : full.failures) observed.put(f.file(), f.type() == ResultProcessor.FailureType.BUG ? "NO_NAME" : f.type().name());
        int mismatches = 0;
        for (String f : manifest) if (!truth.get(f).equals(observed.get(f))) { mismatches++; if (mismatches <= 5) System.out.println("  MISMATCH " + f + " truth=" + truth.get(f) + " observed=" + observed.get(f)); }
        System.out.printf("  processed %,d, failed %,d -> %s%n", full.processed, full.failures.size(), full.failureCounts());
        System.out.printf("  grade distribution %s%n", full.grades);
        System.out.printf("  per-file mismatches vs ground truth: %d ; complete: %b ; BUG failures recorded instead of crashing: %d%n",
                mismatches, full.complete(), full.failureCounts().getOrDefault(ResultProcessor.FailureType.BUG, 0));
        try (PrintWriter out = new PrintWriter("data/q7_failures.csv")) {
            out.println("file,type,detail");
            for (ResultProcessor.Failure f : full.failures) out.printf("%s,%s,\"%s\"%n", f.file(), f.type(), f.detail().replace("\"", "'"));
        }
        try (PrintWriter out = new PrintWriter("data/q7_summary.txt")) {
            out.printf("manifest=%d%nprocessed=%d%nfailed=%d%nfailures=%s%ngrades=%s%n", full.manifest, full.processed, full.failures.size(), full.failureCounts(), full.grades);
        }

        // ======================================================= 3. pool sizes
        System.out.println("\n=== 3. Total time vs pool size (" + manifest.size() + " files; CPUs = " + Runtime.getRuntime().availableProcessors() + ") ===");
        System.out.printf("  %-6s %24s %10s %30s %10s%n", "pool", "local disk: ms (mean of 5)", "speed-up", "storage latency 1 ms/file: ms", "speed-up");
        try (PrintWriter csv = new PrintWriter("data/q7_pool.csv")) {
            csv.println("mode,pool,run,ms,processed,failed");
            for (int w = 0; w < 2; w++) ResultProcessor.process(work.resolve("scripts"), manifest, 4, 0, 5_000);   // warm-up
            double base0 = 0, base1 = 0;
            for (int p : new int[]{1, 2, 4, 8, 16}) {
                double[] mean = new double[2];
                for (int mode = 0; mode < 2; mode++) {
                    int runs = mode == 0 ? 5 : 3;
                    for (int r = 1; r <= runs; r++) {
                        ResultProcessor.Summary s = ResultProcessor.process(work.resolve("scripts"), manifest, p, mode, 5_000);
                        if (s.processed != full.processed || s.failures.size() != full.failures.size()) throw new IllegalStateException("different summary at p=" + p);
                        mean[mode] += s.elapsedMs;
                        csv.printf("%s,%d,%d,%d,%d,%d%n", mode == 0 ? "local" : "latency1ms", p, r, s.elapsedMs, s.processed, s.failures.size());
                    }
                    mean[mode] /= runs;
                }
                if (p == 1) { base0 = mean[0]; base1 = mean[1]; }
                System.out.printf("  %-6d %24.0f %9.2fx %30.0f %9.2fx%n", p, mean[0], base0 / mean[0], mean[1], base1 / mean[1]);
            }
        }
        System.out.println("  every run produced the identical summary (checked)");

        // ======================================================= 4. alternatives
        System.out.println("\n=== 4. Alternative designs on the same " + manifest.size() + " files ===");
        Path dir = work.resolve("scripts");
        // 4a. parallel stream, exception allowed to escape the lambda
        long t0 = System.nanoTime();
        ConcurrentHashMap<String, ResultProcessor.StudentResult> res = new ConcurrentHashMap<>();
        String outcome;
        try {
            manifest.parallelStream().forEach(f -> {
                try { new ResultProcessor.ScoreTask(dir.resolve(f), res, 0).call(); }
                catch (Exception e) { throw new RuntimeException(e); }          // checked exceptions are not allowed in a lambda
            });
            outcome = "completed";
        } catch (RuntimeException e) {
            outcome = "ABORTED by " + e.getCause().getClass().getSimpleName();
        }
        System.out.printf("  parallelStream, exception escapes : %-34s results kept %,d of %,d, %.0f ms (common pool, %d threads)%n",
                outcome, res.size(), manifest.size(), (System.nanoTime() - t0) / 1e6, java.util.concurrent.ForkJoinPool.getCommonPoolParallelism());
        // 4b. parallel stream, exception converted to a failure record inside the lambda
        t0 = System.nanoTime();
        ConcurrentHashMap<String, ResultProcessor.StudentResult> res2 = new ConcurrentHashMap<>();
        AtomicInteger fails = new AtomicInteger();
        manifest.parallelStream().forEach(f -> {
            try { new ResultProcessor.ScoreTask(dir.resolve(f), res2, 0).call(); }
            catch (Exception | Error e) { fails.incrementAndGet(); }
        });
        System.out.printf("  parallelStream, catch in lambda   : %-34s results %,d + failures %,d, %.0f ms (no timeout possible per file)%n",
                "completed", res2.size(), fails.get(), (System.nanoTime() - t0) / 1e6);
        // 4c. one thread per file
        for (int latency : new int[]{0, 1}) {
            ConcurrentHashMap<String, ResultProcessor.StudentResult> res3 = new ConcurrentHashMap<>();
            AtomicInteger fails3 = new AtomicInteger(), live = new AtomicInteger(), peak = new AtomicInteger();
            List<Thread> ts = new ArrayList<>(manifest.size());
            long nmt0 = nmtThreadKb();
            t0 = System.nanoTime();
            for (String f : manifest) {
                Thread t = new Thread(() -> {
                    peak.accumulateAndGet(live.incrementAndGet(), Math::max);
                    try { new ResultProcessor.ScoreTask(dir.resolve(f), res3, latency).call(); }
                    catch (Exception | Error e) { fails3.incrementAndGet(); }
                    finally { live.decrementAndGet(); }
                });
                ts.add(t); t.start();
            }
            for (Thread t : ts) t.join();
            System.out.printf("  one thread per file (latency %d ms): %-34s results %,d + failures %,d, %.0f ms, %,d threads created, peak alive %,d%n",
                    latency, "completed", res3.size(), fails3.get(), (System.nanoTime() - t0) / 1e6, ts.size(), peak.get());
        }
        System.out.println("  thread stack: see Q4 measurement (~1 MB reserved, ~90 KB committed per live thread)");
        System.out.println("Raw data: data/q7_pool.csv, data/q7_failures.csv, data/q7_summary.txt");
    }

    static long nmtThreadKb() { return -1; }
}
