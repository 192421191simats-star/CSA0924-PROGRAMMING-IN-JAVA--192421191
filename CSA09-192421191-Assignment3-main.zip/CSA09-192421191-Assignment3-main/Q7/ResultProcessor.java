import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * Q7 - Semester result processing: concurrent, fault-tolerant.
 *
 *   main thread                     worker pool (p threads)
 *   -----------                     -----------------------
 *   read manifest (n files)
 *   submit n ScoreTask  ------->    ScoreTask.call(): read -> validate -> compute
 *                                     success: results.put(file, result)   (ConcurrentHashMap)
 *                                     failure: throws -> captured in its Future
 *   for each Future (manifest order):
 *     get(timeout) -> ok
 *     ExecutionException -> classify cause -> failure record
 *     TimeoutException   -> cancel(true)   -> failure record
 *   duplicate regNo check (manifest order, deterministic)
 *   summary + completeness check: successes + failures == n
 */
public final class ResultProcessor {

    // ------------------------------------------------------------------ domain
    public record StudentResult(String file, String regNo, String name, String course, int[] marks, int total, double percent, String grade, boolean pass) { }

    public enum FailureType { MISSING, EMPTY, CORRUPT_MARKS, WRONG_FIELD_COUNT, OUT_OF_RANGE, DUPLICATE, IO_ERROR, TIMEOUT, BUG }

    public record Failure(String file, FailureType type, String detail) { }

    /** Checked: a score file that exists but cannot be used. Carries the failure category. */
    public static final class ScoreFileFormatException extends Exception {
        final FailureType type;
        ScoreFileFormatException(String file, FailureType type, String detail) { super(file + ": " + detail); this.type = type; }
    }

    // ------------------------------------------------------------------ one task per file
    static final class ScoreTask implements Callable<StudentResult> {
        private final Path file; private final ConcurrentHashMap<String, StudentResult> results; private final int latencyMs;
        ScoreTask(Path file, ConcurrentHashMap<String, StudentResult> results, int latencyMs) { this.file = file; this.results = results; this.latencyMs = latencyMs; }

        @Override public StudentResult call() throws IOException, ScoreFileFormatException, InterruptedException {
            if (latencyMs > 0) Thread.sleep(latencyMs);                       // simulated network-storage delay
            String name = file.getFileName().toString();
            List<String> lines = Files.readAllLines(file);                    // NoSuchFileException if missing
            if (lines.isEmpty()) throw new ScoreFileFormatException(name, FailureType.EMPTY, "file is empty");
            Map<String, String> f = new LinkedHashMap<>();
            for (String l : lines) { int eq = l.indexOf('='); if (eq > 0) f.put(l.substring(0, eq).trim(), l.substring(eq + 1).trim()); }
            String[] parts = f.getOrDefault("marks", "").split(",");
            if (parts.length != 5) throw new ScoreFileFormatException(name, FailureType.WRONG_FIELD_COUNT, "expected 5 marks, found " + parts.length);
            int[] marks = new int[5];
            for (int i = 0; i < 5; i++) {
                try { marks[i] = Integer.parseInt(parts[i].trim()); }
                catch (NumberFormatException e) { throw new ScoreFileFormatException(name, FailureType.CORRUPT_MARKS, "mark " + (i + 1) + " is '" + parts[i] + "'"); }
                if (marks[i] < 0 || marks[i] > 100) throw new ScoreFileFormatException(name, FailureType.OUT_OF_RANGE, "mark " + (i + 1) + " = " + marks[i]);
            }
            String student = f.get("name").toUpperCase();                    // BUG on purpose: NPE when the name line is missing
            int total = 0; boolean pass = true;
            for (int m : marks) { total += m; if (m < 40) pass = false; }
            double pct = total / 5.0;
            String grade = !pass ? "F" : pct >= 90 ? "O" : pct >= 80 ? "A+" : pct >= 70 ? "A" : pct >= 60 ? "B+" : pct >= 50 ? "B" : "C";
            StudentResult r = new StudentResult(name, f.get("regNo"), student, f.get("course"), marks, total, pct, grade, pass);
            results.put(name, r);                                              // shared, written by many threads
            return r;
        }
    }

    // ------------------------------------------------------------------ the run
    public static final class Summary {
        public int manifest, processed;
        public final List<Failure> failures = new ArrayList<>();
        public final Map<String, StudentResult> results = new TreeMap<>();
        public final Map<String, Integer> grades = new TreeMap<>();
        public long elapsedMs;
        public int threadsUsed;
        public Map<FailureType, Integer> failureCounts() {
            Map<FailureType, Integer> m = new EnumMap<>(FailureType.class);
            for (Failure f : failures) m.merge(f.type(), 1, Integer::sum);
            return m;
        }
        public boolean complete() { return processed + failures.size() == manifest; }
    }

    public static Summary process(Path scriptsDir, List<String> manifest, int poolSize, int latencyMs, long timeoutMs) throws InterruptedException {
        Summary s = new Summary();
        s.manifest = manifest.size();
        ConcurrentHashMap<String, StudentResult> results = new ConcurrentHashMap<>(manifest.size() * 2);
        Set<String> workerThreads = ConcurrentHashMap.newKeySet();
        ExecutorService pool = Executors.newFixedThreadPool(poolSize);
        long t0 = System.nanoTime();
        try {
            List<Future<StudentResult>> futures = new ArrayList<>(manifest.size());
            for (String file : manifest) {
                ScoreTask task = new ScoreTask(scriptsDir.resolve(file), results, latencyMs);
                futures.add(pool.submit(() -> { workerThreads.add(Thread.currentThread().getName()); return task.call(); }));
            }
            for (int i = 0; i < futures.size(); i++) {                         // collect in manifest order
                String file = manifest.get(i);
                try {
                    futures.get(i).get(timeoutMs, TimeUnit.MILLISECONDS);
                } catch (ExecutionException e) {                               // the task threw: record, keep going
                    s.failures.add(classify(file, e.getCause()));
                } catch (TimeoutException e) {
                    futures.get(i).cancel(true);
                    results.remove(file);
                    s.failures.add(new Failure(file, FailureType.TIMEOUT, "no result within " + timeoutMs + " ms"));
                }
            }
        } finally {
            pool.shutdown();
            if (!pool.awaitTermination(10, TimeUnit.SECONDS)) pool.shutdownNow();
        }
        // duplicates: decided in manifest order, so the outcome never depends on thread timing
        Set<String> seenReg = new HashSet<>();
        for (String file : manifest) {
            StudentResult r = results.get(file);
            if (r == null) continue;
            if (!seenReg.add(r.regNo())) s.failures.add(new Failure(file, FailureType.DUPLICATE, "regNo " + r.regNo() + " already processed"));
            else { s.results.put(file, r); s.grades.merge(r.grade(), 1, Integer::sum); }
        }
        s.processed = s.results.size();
        s.elapsedMs = (System.nanoTime() - t0) / 1_000_000;
        s.threadsUsed = workerThreads.size();
        s.failures.sort((a, b) -> a.file().compareTo(b.file()));
        return s;
    }

    static Failure classify(String file, Throwable cause) {
        if (cause instanceof ScoreFileFormatException sf) return new Failure(file, sf.type, sf.getMessage());
        if (cause instanceof NoSuchFileException) return new Failure(file, FailureType.MISSING, "file not found");
        if (cause instanceof IOException io) return new Failure(file, FailureType.IO_ERROR, io.toString());
        return new Failure(file, FailureType.BUG, cause.toString());           // unexpected RuntimeException / Error
    }

    public static List<String> readManifest(Path manifestFile) throws IOException {
        List<String> m = new ArrayList<>();
        for (String l : Files.readAllLines(manifestFile)) if (!l.isBlank() && !l.startsWith("#")) m.add(l.trim());
        return Collections.unmodifiableList(m);
    }
}
