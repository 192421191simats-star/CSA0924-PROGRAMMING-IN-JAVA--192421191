import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Q5 - Cinema seat booking: reproducing the race, and comparing synchronization strategies.
 *
 * Compile: javac -d out BookingLab.java
 * Run    : java -cp out BookingLab
 */
public class BookingLab {

    /** Work done for every booking request OUTSIDE the seat check (validate user, compute price, build ticket). */
    static int WORK = 400;
    static long requestWork(int user) {
        long h = user;
        for (int i = 0; i < WORK; i++) h = h * 6364136223846793005L + 1442695040888963407L;
        return h;
    }

    /** A "payment authorisation" pause between checking a seat and marking it (widens the race window). */
    static void paymentCheck(int spins) { for (int i = 0; i < spins; i++) Thread.onSpinWait(); }

    // ======================================================================= implementations
    interface Screen { boolean book(int seat, int user); int sold(); String name(); }

    /** 0 - no synchronization (broken). */
    static final class Unsafe implements Screen {
        final boolean[] booked; int sold; final int spins;
        Unsafe(int seats, int spins) { booked = new boolean[seats]; this.spins = spins; }
        public boolean book(int seat, int user) {
            if (requestWork(user) == 42) return false;   // result used so the JIT cannot remove the work
            if (!booked[seat]) {                // CHECK
                paymentCheck(spins);
                booked[seat] = true;            // ACT
                sold++;                         // read-modify-write
                return true;
            }
            return false;
        }
        public int sold() { return sold; }
        public String name() { return "no synchronization"; }
    }

    /** 1 - synchronized method: the whole request holds the screen's lock. */
    static final class SyncMethod implements Screen {
        final boolean[] booked; int sold; final int spins;
        SyncMethod(int seats, int spins) { booked = new boolean[seats]; this.spins = spins; }
        public synchronized boolean book(int seat, int user) {   // lock = this
            if (requestWork(user) == 42) return false;   // result used so the JIT cannot remove the work
            if (!booked[seat]) { paymentCheck(spins); booked[seat] = true; sold++; return true; }
            return false;
        }
        public synchronized int sold() { return sold; }
        public String name() { return "synchronized method"; }
    }

    /** 2 - synchronized block: only the critical section (check + act + count) holds the lock. */
    static final class SyncBlock implements Screen {
        final boolean[] booked; int sold; final int spins; private final Object lock = new Object();
        SyncBlock(int seats, int spins) { booked = new boolean[seats]; this.spins = spins; }
        public boolean book(int seat, int user) {
            if (requestWork(user) == 42) return false;                                    // outside the lock   // result used so the JIT cannot remove the work
            synchronized (lock) {                                 // lock = private object
                if (booked[seat]) return false;
                paymentCheck(spins);
                booked[seat] = true; sold++; return true;
            }
        }
        public int sold() { synchronized (lock) { return sold; } }
        public String name() { return "synchronized block"; }
    }

    /** 3 - AtomicBoolean per seat, compareAndSet (lock-free). */
    static final class Cas implements Screen {
        final AtomicBoolean[] booked; final AtomicInteger sold = new AtomicInteger(); final int spins;
        Cas(int seats, int spins) { booked = new AtomicBoolean[seats]; for (int i = 0; i < seats; i++) booked[i] = new AtomicBoolean(); this.spins = spins; }
        public boolean book(int seat, int user) {
            if (requestWork(user) == 42) return false;   // result used so the JIT cannot remove the work
            if (booked[seat].get()) return false;                  // cheap pre-check, like the other versions
            paymentCheck(spins);
            if (booked[seat].compareAndSet(false, true)) { sold.incrementAndGet(); return true; }   // atomic decision
            return false;
        }
        public int sold() { return sold.get(); }
        public String name() { return "AtomicBoolean[] CAS"; }
    }

    /** 4 - ReentrantLock around the critical section. */
    static final class Locked implements Screen {
        final boolean[] booked; int sold; final int spins; final ReentrantLock lock = new ReentrantLock();
        Locked(int seats, int spins) { booked = new boolean[seats]; this.spins = spins; }
        public boolean book(int seat, int user) {
            if (requestWork(user) == 42) return false;   // result used so the JIT cannot remove the work
            lock.lock();
            try {
                if (booked[seat]) return false;
                paymentCheck(spins);
                booked[seat] = true; sold++; return true;
            } finally { lock.unlock(); }
        }
        public int sold() { lock.lock(); try { return sold; } finally { lock.unlock(); } }
        public String name() { return "ReentrantLock"; }
    }

    /** 5 - ConcurrentHashMap<seat, user>.putIfAbsent. */
    static final class MapBased implements Screen {
        final ConcurrentHashMap<Integer, Integer> owner = new ConcurrentHashMap<>(); final int spins;
        MapBased(int seats, int spins) { this.spins = spins; }
        public boolean book(int seat, int user) {
            if (requestWork(user) == 42) return false;   // result used so the JIT cannot remove the work
            if (owner.containsKey(seat)) return false;
            paymentCheck(spins);
            return owner.putIfAbsent(seat, user) == null;          // atomic decision
        }
        public int sold() { return owner.size(); }
        public String name() { return "ConcurrentHashMap.putIfAbsent"; }
    }

    static Screen make(int kind, int seats, int spins) {
        return switch (kind) {
            case 0 -> new Unsafe(seats, spins); case 1 -> new SyncMethod(seats, spins); case 2 -> new SyncBlock(seats, spins);
            case 3 -> new Cas(seats, spins); case 4 -> new Locked(seats, spins); default -> new MapBased(seats, spins);
        };
    }

    /** Runs `threads` threads released together; each makes `perThread` requests for seats chosen round-robin. */
    static int[] contest(Screen s, int seats, int threads, int perThread) throws InterruptedException {
        CountDownLatch start = new CountDownLatch(1);
        AtomicInteger successes = new AtomicInteger();
        Thread[] ts = new Thread[threads];
        for (int t = 0; t < threads; t++) {
            final int id = t;
            ts[t] = new Thread(() -> {
                try { start.await(); } catch (InterruptedException e) { return; }
                for (int k = 0; k < perThread; k++)
                    if (s.book((k + id) % seats, id)) successes.incrementAndGet();   // every seat contested by all threads
            });
            ts[t].start();
        }
        start.countDown();                                                         // release all at once
        for (Thread t : ts) t.join();
        return new int[]{successes.get(), s.sold()};
    }

    public static void main(String[] args) throws Exception {
        Files.createDirectories(Path.of("data"));

        // ------------------------------------------------ A. reproduce the race reliably
        System.out.println("=== A. Reproducing double booking: 10 seats, 20 threads released together by a latch ===");
        System.out.println("  'successes' = how many users were told 'seat confirmed' (must be <= 10)");
        System.out.printf("  %-36s %-6s %-12s %-14s %-12s%n", "test", "run", "successes", "double-booked", "sold counter");
        try (PrintWriter csv = new PrintWriter("data/q5_race.csv")) {
            csv.println("test,run,successes,double_booked,sold_counter");
            String[] tests = {"natural (no pause)", "with payment check (2,000 spins)"};
            int[] spins = {0, 2_000};
            for (int t = 0; t < 2; t++) {
                int totalDouble = 0, runsWithDouble = 0, runs = t == 0 ? 500 : 10;
                for (int run = 1; run <= runs; run++) {
                    int[] r = contest(make(0, 10, spins[t]), 10, 20, 10);
                    int dbl = Math.max(0, r[0] - 10);
                    totalDouble += dbl;
                    if (dbl > 0) runsWithDouble++;
                    if (t == 1 || dbl > 0) System.out.printf("  %-36s %-6d %-12d %-14d %-12d%n", tests[t], run, r[0], dbl, r[1]);
                    csv.printf("%s,%d,%d,%d,%d%n", tests[t], run, r[0], dbl, r[1]);
                }
                System.out.printf("  -> %s: %d double bookings, in %d of %d runs%n%n", tests[t], totalDouble, runsWithDouble, runs);
            }
            System.out.println("  Same two tests with every synchronized / atomic version (10 runs each):");
            for (int kind = 1; kind <= 5; kind++)
                for (int t = 0; t < 2; t++) {
                    int worst = 0;
                    for (int run = 1; run <= 10; run++) {
                        int[] r = contest(make(kind, 10, spins[t]), 10, 20, 10);
                        worst = Math.max(worst, r[0]);
                        csv.printf("%s / %s,%d,%d,%d,%d%n", make(kind, 1, 0).name(), tests[t], run, r[0], Math.max(0, r[0] - 10), r[1]);
                    }
                    System.out.printf("  %-32s %-34s max successes in 10 runs = %d -> %s%n", make(kind, 1, 0).name(), tests[t], worst,
                            worst == 10 ? "never double-booked" : "DOUBLE BOOKED");
                }
        }

        // ------------------------------------------------ B. timing 10,000 bookings
        WORK = 20_000;                     // per-request work (validation, pricing, ticket text) - a few microseconds
        System.out.println("\n=== B. Time to process 10,000 booking requests (8 threads, 1,000 seats, per-request validation + pricing work, mean of 7 runs) ===");
        System.out.printf("  %-32s %12s %12s %16s%n", "version", "ms", "us/request", "seats sold");
        try (PrintWriter csv = new PrintWriter("data/q5_timing.csv")) {
            csv.println("version,run,ms,sold");
            for (int kind = 0; kind <= 5; kind++) {
                for (int w = 0; w < 3; w++) contest(make(kind, 1000, 200), 1000, 8, 1250);
                double total = 0; int sold = 0;
                for (int run = 1; run <= 7; run++) {
                    Screen s = make(kind, 1000, 200);
                    long t0 = System.nanoTime();
                    int[] r = contest(s, 1000, 8, 1250);
                    double ms = (System.nanoTime() - t0) / 1e6;
                    total += ms; sold = r[0];
                    csv.printf("%s,%d,%.3f,%d%n", s.name(), run, ms, r[0]);
                }
                System.out.printf("  %-32s %12.2f %12.3f %16d%s%n", make(kind, 1, 0).name(), total / 7, total / 7 * 1000 / 10_000, sold,
                        kind == 0 && sold > 1000 ? "  <- more than 1,000 seats: double bookings" : "");
            }
        }

        // ------------------------------------------------ C. static synchronization: 20 screens, one total
        System.out.println("\n=== C. 20 screens x 50,000 seat bookings, one cinema-wide 'tickets sold today' counter (static) ===");
        for (int mode = 0; mode < 2; mode++) {
            CinemaScreen.total = 0;
            CinemaScreen[] screens = new CinemaScreen[20];
            for (int i = 0; i < 20; i++) screens[i] = new CinemaScreen(50_000);
            Thread[] ts = new Thread[20];
            final int m = mode;
            for (int i = 0; i < 20; i++) {
                final CinemaScreen sc = screens[i];
                ts[i] = new Thread(() -> { for (int seat = 0; seat < 50_000; seat++) sc.book(seat, m == 1); });
                ts[i].start();
            }
            for (Thread t : ts) t.join();
            int perScreen = 0;
            for (CinemaScreen sc : screens) perScreen += sc.sold;
            System.out.printf("  %-58s seats sold %,d ; static total %,d -> %s%n",
                    mode == 0 ? "instance-synchronized book() updates static total" : "static synchronized addToTotal()",
                    perScreen, CinemaScreen.total, perScreen == CinemaScreen.total ? "correct" : "LOST UPDATES");
        }
        System.out.println("Raw data: data/q5_race.csv, data/q5_timing.csv");
    }

    /** One screen; instance lock protects its seats, but the cinema-wide total is shared by all screens. */
    static final class CinemaScreen {
        static int total;                                    // shared by ALL screens
        final boolean[] booked; int sold;
        CinemaScreen(int seats) { booked = new boolean[seats]; }
        synchronized void book(int seat, boolean useStatic) { // lock = this screen only
            if (booked[seat]) return;
            booked[seat] = true; sold++;
            if (useStatic) addToTotal(); else total++;       // total++ under an INSTANCE lock is not protected
        }
        static synchronized void addToTotal() { total++; }    // lock = CinemaScreen.class
    }
}
