import java.nio.file.Path;
import java.util.Scanner;

/**
 * Q1 - Student B: an exception that is NOT caught by the ATM. The customer presses Enter on an
 * empty keypad stream (end of input), Scanner.nextInt() throws NoSuchElementException, which no
 * catch block handles: finally still runs, then the exception propagates out of main and the JVM
 * prints the stack trace.
 *
 * Run: java -cp out UncaughtDemo < /dev/null
 */
public class UncaughtDemo {
    public static void main(String[] args) throws Exception {
        AtmSimulation atm = new AtmSimulation(Path.of("input/accounts.csv"));
        Scanner keypad = new Scanner(System.in);
        AtmSimulation.Trace t = atm.withdraw("input/card_valid.txt", keypad);   // never returns normally
        System.out.println("not reached: " + t.path);
    }
}
