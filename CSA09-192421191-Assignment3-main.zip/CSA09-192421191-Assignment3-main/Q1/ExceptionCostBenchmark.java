import java.io.PrintWriter;
import java.lang.management.ManagementFactory;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

/**
 * Q1 alternative concept: exceptions vs error codes.
 *  (1) the error-code ATM (no exceptions): hasNextInt() + return codes
 *  (2) cost of signalling a failure: return -1 vs throw/catch, at call depths 1, 10, 100,
 *      with and without stack-trace capture. Raw data -> data/q1_exception_cost.csv
 *
 * Run: java -cp out ExceptionCostBenchmark
 */
public class ExceptionCostBenchmark {

    // ---------------------------------------------------------------- (1) error-code version
    static final int OK = 0, ERR_NOT_A_NUMBER = -1, ERR_NOT_POSITIVE = -2, ERR_NOT_MULTIPLE = -3,
            ERR_LIMIT = -4, ERR_FUNDS = -5, ERR_NO_INPUT = -6;

    /** Every check is written by hand and every caller must remember to test the code. */
    static int withdrawWithCodes(Scanner in, long[] balance) {
        if (!in.hasNext()) return ERR_NO_INPUT;
        if (!in.hasNextInt()) { in.next(); return ERR_NOT_A_NUMBER; }
        int amount = in.nextInt();
        if (amount <= 0) return ERR_NOT_POSITIVE;
        if (amount % 100 != 0) return ERR_NOT_MULTIPLE;
        if (amount > 20_000) return ERR_LIMIT;
        if (amount > balance[0]) return ERR_FUNDS;
        balance[0] -= amount;
        return OK;
    }

    static String describe(int code) {
        return switch (code) {
            case OK -> "OK"; case ERR_NOT_A_NUMBER -> "-1 not a number"; case ERR_NOT_POSITIVE -> "-2 not positive";
            case ERR_NOT_MULTIPLE -> "-3 not multiple of 100"; case ERR_LIMIT -> "-4 over daily limit";
            case ERR_FUNDS -> "-5 insufficient funds"; default -> "-6 no input";
        };
    }

    // ---------------------------------------------------------------- (2) signalling cost
    static final class Failure extends Exception {
        Failure(boolean stackTrace) { super("insufficient funds", null, false, stackTrace); }
    }
    static final Failure PREALLOCATED = new Failure(false);

    static int codeAt(int depth, int amount) { return depth == 0 ? (amount > 1000 ? -5 : amount) : codeAt(depth - 1, amount); }
    static int throwAt(int depth, int amount, int mode) throws Failure {
        if (depth == 0) {
            if (amount > 1000) {
                if (mode == 0) throw new Failure(true);       // normal exception: captures stack trace
                if (mode == 1) throw new Failure(false);      // no stack trace
                throw PREALLOCATED;                           // reused object
            }
            return amount;
        }
        return throwAt(depth - 1, amount, mode);
    }

    @SuppressWarnings("deprecation")
    static long allocated() {
        return ((com.sun.management.ThreadMXBean) ManagementFactory.getThreadMXBean())
                .getThreadAllocatedBytes(Thread.currentThread().getId());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== (1) Error-code ATM (no exceptions) on the same typed inputs ===");
        String[] typed = {"2000", "abc", "-500", "250", "30000", "5000", ""};
        for (String t : typed) {
            long[] bal = {1200};
            System.out.printf("  input %-7s -> code %s%n", "\"" + t + "\"", describe(withdrawWithCodes(new Scanner(t), bal)));
        }
        System.out.println("  card file / account errors would need yet more codes, and every caller must check them");

        System.out.println("\n=== (2) Cost of reporting ONE failure (ns per failed call, mean of 5 runs x 200,000 calls) ===");
        System.out.printf("  %-34s %10s %10s %10s %16s%n", "mechanism", "depth 1", "depth 10", "depth 100", "bytes/fail (d=100)");
        String[] names = {"return error code -5", "throw new exception (stack trace)", "throw new exception (no trace)", "throw pre-allocated exception"};
        Files.createDirectories(Path.of("data"));
        try (PrintWriter csv = new PrintWriter("data/q1_exception_cost.csv")) {
            csv.println("mechanism,depth,run,ns_per_failure,bytes_per_failure");
            for (int m = -1; m < 3; m++) {
                System.out.printf("  %-34s", names[m + 1]);
                long bytesDeep = 0;
                for (int depth : new int[]{1, 10, 100}) {
                    int calls = 200_000;
                    long sink = 0;
                    for (int w = 0; w < 3; w++) sink += run(m, depth, calls);         // warm-up
                    double total = 0;
                    for (int r = 1; r <= 5; r++) {
                        long a0 = allocated(), t0 = System.nanoTime();
                        sink += run(m, depth, calls);
                        long t1 = System.nanoTime(), a1 = allocated();
                        double ns = (t1 - t0) / (double) calls;
                        long bytes = (a1 - a0) / calls;
                        total += ns;
                        if (depth == 100) bytesDeep = bytes;
                        csv.printf("%s,%d,%d,%.2f,%d%n", names[m + 1], depth, r, ns, bytes);
                    }
                    System.out.printf(" %10.1f", total / 5);
                    if (sink == 42) System.out.print("");
                }
                System.out.printf(" %16d%n", bytesDeep);
            }
        }
        System.out.println("Raw data: data/q1_exception_cost.csv");
    }

    static long run(int mode, int depth, int calls) {
        long s = 0;
        for (int i = 0; i < calls; i++) {
            if (mode < 0) s += codeAt(depth, 5000);
            else try { s += throwAt(depth, 5000, mode); } catch (Failure f) { s += 1; }
        }
        return s;
    }
}
