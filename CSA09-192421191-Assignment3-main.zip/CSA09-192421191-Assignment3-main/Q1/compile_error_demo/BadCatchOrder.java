// Q1 - Student B: a BROADER catch placed before a NARROWER one. This file intentionally
// does NOT compile; the compiler error is the evidence (see output/BadCatchOrder_compile.txt).
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class BadCatchOrder {
    public static void main(String[] args) {
        try {
            new FileReader("input/card_missing.txt").close();
        } catch (IOException e) {                       // broader first ...
            System.out.println("IO problem");
        } catch (FileNotFoundException e) {             // ... makes this one unreachable
            System.out.println("card missing");
        }
        try {
            Long.parseLong("12AB");
        } catch (IllegalArgumentException e) {          // superclass of NumberFormatException
            System.out.println("bad argument");
        } catch (NumberFormatException e) {             // unreachable too
            System.out.println("bad number");
        }
    }
}
