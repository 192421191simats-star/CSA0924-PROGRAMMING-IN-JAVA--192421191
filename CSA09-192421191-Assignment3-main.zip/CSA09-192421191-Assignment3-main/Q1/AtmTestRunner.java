import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Scanner;

/**
 * Q1 - Student B: runs every designed test input through the ATM and records which
 * catch block handled it and whether finally ran. Writes data/q1_tests.csv.
 *
 * Run: java -cp out AtmTestRunner input/test_cases.csv
 */
public class AtmTestRunner {
    public static void main(String[] args) throws IOException {
        Files.createDirectories(Path.of("data"));
        String fmt = "%-4s %-30s %-28s %-8s %-28s %-8s %-6s %s%n";
        System.out.printf(fmt, "ID", "test input", "catch block that ran", "finally", "expected path", "result", "file", "message shown");
        System.out.println("-".repeat(165));
        int pass = 0, total = 0;
        try (PrintWriter csv = new PrintWriter("data/q1_tests.csv")) {
            csv.println("id,description,card_file,typed,expected,observed,finally_ran,card_closed,message");
            for (String line : Files.readAllLines(Path.of(args.length > 0 ? args[0] : "input/test_cases.csv"))) {
                if (line.isBlank() || line.startsWith("#")) continue;
                String[] p = line.split("\\|");
                AtmSimulation atm = new AtmSimulation(Path.of("input/accounts.csv"));   // fresh balances per test
                AtmSimulation.Trace t = atm.withdraw(p[2], new Scanner(p[3].replace("\\n", "\n")));
                boolean ok = t.path.equals(p[4]);
                boolean closed = t.log.contains("card file closed");
                total++; if (ok) pass++;
                System.out.printf(fmt, p[0], p[1] + " [" + p[3] + "]", t.path, t.finallyRan, p[4], ok ? "PASS" : "FAIL",
                        closed ? "closed" : "-", t.message);
                csv.printf("%s,\"%s\",%s,\"%s\",%s,%s,%b,%b,\"%s\"%n", p[0], p[1], p[2], p[3], p[4], t.path, t.finallyRan, closed, t.message);
            }
        }
        System.out.println("-".repeat(165));
        System.out.println(pass + " / " + total + " paths as designed; finally ran in every test; 'file' = card file closed in finally");
    }
}
