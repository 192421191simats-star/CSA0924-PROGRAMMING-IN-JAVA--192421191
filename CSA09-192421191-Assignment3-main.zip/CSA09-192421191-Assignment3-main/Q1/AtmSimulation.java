import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Q1 - Bank ATM withdrawal with try / catch (incl. multi-catch) / finally.
 *
 * Failure points and how they are reported:
 *   card file missing         -> FileNotFoundException            (checked,   caught)
 *   card file blank / unreadable -> CardReadException extends IOException (checked, caught)
 *   letters on the card       -> NumberFormatException            (unchecked, caught - multi-catch)
 *   unknown account           -> AccountNotFoundException          (checked,   caught - multi-catch)
 *   letters typed as amount   -> InputMismatchException           (unchecked, caught - multi-catch)
 *   amount <= 0, not x100, > limit -> IllegalArgumentException    (unchecked, caught)
 *   amount > balance          -> InsufficientFundsException       (checked,   caught - multi-catch)
 *   no input at all (EOF)     -> NoSuchElementException           (unchecked, NOT caught -> propagates)
 *   JVM out of memory etc.    -> Error                            (never caught)
 *
 * Interactive run: java -cp out AtmSimulation input/card_valid.txt
 */
public class AtmSimulation {

    // ------------------------------------------------------------------ user-defined exceptions
    /** Checked: the customer can recover (choose a smaller amount). */
    static class InsufficientFundsException extends Exception {
        InsufficientFundsException(long requested, long balance) {
            super("Requested Rs " + requested + " but balance is Rs " + balance);
        }
    }
    /** Checked: the card is valid but the bank does not know the account (call the bank). */
    static class AccountNotFoundException extends Exception {
        AccountNotFoundException(long acc) { super("No account " + acc); }
    }
    /** Checked, an IOException: the card file exists but no account number could be read. */
    static class CardReadException extends IOException {
        CardReadException(String msg) { super(msg); }
    }

    // ------------------------------------------------------------------ bank
    static final class Account {
        final long number; final String holder; private long balance;
        Account(long n, String h, long b) { number = n; holder = h; balance = b; }
        long balance() { return balance; }

        void withdraw(long amount) throws InsufficientFundsException {
            if (amount <= 0) throw new IllegalArgumentException("Amount must be positive: " + amount);
            if (amount % 100 != 0) throw new IllegalArgumentException("Amount must be a multiple of 100: " + amount);
            if (amount > DAILY_LIMIT) throw new IllegalArgumentException("Amount exceeds daily limit of Rs " + DAILY_LIMIT);
            if (amount > balance) throw new InsufficientFundsException(amount, balance);
            balance -= amount;
        }
    }

    static final long DAILY_LIMIT = 20_000;
    final Map<Long, Account> accounts = new HashMap<>();

    AtmSimulation(Path accountsFile) throws IOException {
        for (String line : Files.readAllLines(accountsFile)) {
            if (line.isBlank() || line.startsWith("#")) continue;
            String[] p = line.split(",");
            long n = Long.parseLong(p[0].trim());
            accounts.put(n, new Account(n, p[1].trim(), Long.parseLong(p[2].trim())));
        }
    }

    Account find(long number) throws AccountNotFoundException {
        Account a = accounts.get(number);
        if (a == null) throw new AccountNotFoundException(number);
        return a;
    }

    // ------------------------------------------------------------------ one ATM session
    /** Records the path taken through the try/catch/finally (evidence for the test table). */
    static final class Trace {
        String path = "(none)";
        String message = "";
        boolean finallyRan;
        final List<String> log = new ArrayList<>();
    }

    /**
     * One withdrawal. Every expected failure is caught here; the session always ends in finally.
     * Note the catch order: FileNotFoundException BEFORE IOException (subclass first),
     * NumberFormatException (inside the multi-catch) BEFORE IllegalArgumentException (its superclass).
     */
    Trace withdraw(String cardFile, Scanner in) {
        Trace tr = new Trace();
        BufferedReader card = null;
        try {
            tr.log.add("insert card " + cardFile);
            card = new BufferedReader(new FileReader(cardFile));          // FileNotFoundException
            String line = card.readLine();                                // IOException
            if (line == null || line.isBlank()) throw new CardReadException("Card has no account number");
            long accountNo = Long.parseLong(line.trim());                 // NumberFormatException
            Account acc = find(accountNo);                                // AccountNotFoundException
            tr.log.add("account " + accountNo + " (" + acc.holder + "), balance Rs " + acc.balance());
            int amount = in.nextInt();                                    // InputMismatchException / NoSuchElementException
            tr.log.add("amount typed: " + amount);
            acc.withdraw(amount);                                         // IllegalArgument / InsufficientFunds
            tr.path = "SUCCESS";
            tr.message = "Dispensed Rs " + amount + ", new balance Rs " + acc.balance();
        } catch (FileNotFoundException e) {                               // narrower IOException first
            tr.path = "FileNotFoundException";
            tr.message = "Card reader error: " + e.getMessage();
        } catch (IOException e) {                                         // covers CardReadException
            tr.path = e.getClass().getSimpleName();
            tr.message = "Could not read card: " + e.getMessage();
        } catch (InputMismatchException | NumberFormatException e) {      // multi-catch: bad number formats
            tr.path = e.getClass().getSimpleName();
            tr.message = e instanceof InputMismatchException ? "Please type digits only"
                                                             : "Card data is corrupt: " + e.getMessage();
            if (e instanceof InputMismatchException) in.next();           // discard the bad token
        } catch (InsufficientFundsException | AccountNotFoundException e) { // multi-catch: business rules
            tr.path = e.getClass().getSimpleName();
            tr.message = e.getMessage();
        } catch (IllegalArgumentException e) {                            // AFTER NumberFormatException
            tr.path = "IllegalArgumentException";
            tr.message = e.getMessage();
        } finally {                                                       // runs on EVERY path, even uncaught
            tr.finallyRan = true;
            if (card != null) {
                try { card.close(); tr.log.add("card file closed"); }
                catch (IOException e) { tr.log.add("close failed: " + e.getMessage()); }
            }
            tr.log.add("card ejected, session ended");
            if (tr.path.equals("(none)"))   // no catch matched: an exception is still propagating
                System.out.println("[finally] card file closed and card ejected although an exception is still propagating");
        }
        return tr;
    }

    public static void main(String[] args) throws IOException {
        AtmSimulation atm = new AtmSimulation(Path.of("input/accounts.csv"));
        String cardFile = args.length > 0 ? args[0] : "input/card_valid.txt";
        System.out.print("Enter amount to withdraw: ");
        Trace t = atm.withdraw(cardFile, new Scanner(System.in));
        System.out.println();
        System.out.println("path    : " + t.path);
        System.out.println("message : " + t.message);
        System.out.println("finally : " + t.finallyRan);
        t.log.forEach(l -> System.out.println("  log: " + l));
    }
}
